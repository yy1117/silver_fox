"""black_hand URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.8/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import include, url
from django.contrib import admin
import settings

urlpatterns = [
    url(r'^admin/', include(admin.site.urls)),
    url(r'^login.html$', 'silver_fox.views.login'),
    url(r'^login_post/$', 'silver_fox.views.login_post'),
    url(r'^func/$', 'silver_fox.views.func'),
    url(r'^blog/config_center/$', 'silver_fox.views.config_center'),
    url(r'^blog/big_table_analysis/$', 'silver_fox.views.big_table_analysis'),
    url(r'^blog/db_status/$', 'silver_fox.views.db_status'),
    url(r'^blog/db_replica/$', 'silver_fox.views.db_replica'),
    url(r'^blog/db_backup/$', 'silver_fox.views.db_backup'),
    url(r'^blog/dbserver_list/$', 'silver_fox.views.dbserver_list'),
    url(r'^blog/dbserver_list_new/$', 'silver_fox.views.dbserver_list_new'),
    url(r'^blog/mysql_monitor_display/$', 'silver_fox.views.mysql_monitor_display'),
    url(r'^blog/options/$', 'silver_fox.views.options'),
    url(r'^blog/auto/$', 'silver_fox.views.auto'),
    url(r'^blog/auto_senior/$', 'silver_fox.views.auto_senior'),
    url(r'^blog/db_auto_install/$', 'silver_fox.views.db_auto_install'),
    url(r'^blog/column_change/$', 'silver_fox.views.column_change_recored'),
    url(r'^blog/dbserver_form/$', 'silver_fox.views.dbserver_form'),
    url(r'^blog/_update/$','silver_fox.views._update'),
    url(r'^blog/_delete/$','silver_fox.views._delete'),
    url(r'^blog/_insert/$','silver_fox.views._insert'),
    url(r'^blog/echarts/$','silver_fox.views.echarts'),
    url(r'^blog/pie_echarts/$','silver_fox.views.pie_echarts'),
    url(r'^blog/ajax_dict/$','silver_fox.views.ajax_dict'),
    url(r'^blog/ajax_dict_old/$','silver_fox.views.ajax_dict'),
    #url(r'^blog/dbserver_form_update/$', 'silver_fox.views.dbserver_form'),
    url(r'^search_from/$', 'silver_fox.views.search_from'),
    url(r'^search/$', 'silver_fox.views.search'),
    url(r'^blog/index/$','silver_fox.views.index'),
    #url(r'^$','silver_fox.views.first'),
    url(r'^blog/first/$','silver_fox.views.first'),
    url(r'^blog/big_total/$','silver_fox.views.big_total'),
    url(r'^blog/test/$','silver_fox.views.test'),
    url(r'^blog/list/$','silver_fox.views.list'),
]
