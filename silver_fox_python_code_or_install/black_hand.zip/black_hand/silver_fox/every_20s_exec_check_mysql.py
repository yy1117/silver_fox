#!/usr/bin/python
# -*- coding:utf-8 -*-
import os
import time
def sleeptime(hour,min,sec):
	return hour*3600 + min*60 + sec
second = sleeptime(0,0,20)
while 1==1:
	time.sleep(second)
	f1=open('bigtable_trend.py','r+')
	f2=open('bigtable_trend_group.py','r+')
	f3=open('tps_qps_display_input_ip.py','r+')
	f1.close()
	f2.close()
	f3.close()
	os.popen('python check_mysql.py')
