#-*- coding:utf8 -*-
import MySQLdb,re,os

import sys,os,MySQLdb
reload(sys)
import MySQLdb,re
import ConfigParser 

def get_config(group,config_name):
    cp = ConfigParser.SafeConfigParser(allow_no_value = True)
    #b = str(os.getcwd())
    b = os.path.abspath('./etc/config.ini')
    #html 报错说目录在/root/csvt01/etc/config.ini 做做了个软连接过去
    cp.readfp(open(b,'rw'))
    config_value=cp.get(group,config_name).strip(' ').strip('\'').strip('\"')
    return config_value


host1  = get_config('monitor_server','host')
port1 = get_config('monitor_server','port')
user1 = get_config('monitor_server','user')
passwd1 = get_config('monitor_server','passwd')
dbname1 = get_config('monitor_server','dbname')

#w_re = "select id_number,real_name,CASE SUBSTR(u.id_number, 1, 2) WHEN 11 THEN '北京市' WHEN 12 THEN '天津市' WHEN 13 THEN '河北省' WHEN 14 THEN '山西省' WHEN 15 THEN '内蒙古自治区' WHEN 21 THEN '辽宁省' WHEN 22 THEN '吉林省' WHEN 23 THEN '黑龙江省' WHEN 31 THEN '上海市' WHEN 32 THEN '江苏省' WHEN 33 THEN '浙江省' WHEN 34 THEN '安徽省' WHEN 35 THEN '福建省' WHEN 36 THEN '江西省' WHEN 37 THEN '山东省' WHEN 41 THEN '河南省' WHEN 42 THEN '湖北省' WHEN 43 THEN '湖南省' WHEN 44 THEN '广东省' WHEN 46 THEN '海南省' WHEN 50 THEN '重庆市' WHEN 51 THEN '四川省' WHEN 52 THEN '贵州省' WHEN 53 THEN '云南省' WHEN 54 THEN '西藏自治区' WHEN 61 THEN '陕西省' WHEN 62 THEN '甘肃省' WHEN 63 THEN '青海省' WHEN 64 THEN '宁夏回族自治区' WHEN 65 THEN '新疆维吾尔自治区' WHEN 71 THEN '台湾省' WHEN 81 THEN '香港特别行政区' WHEN 82 THEN '澳门特别行政区' WHEN 45 THEN '广西壮族自治区' END province,CASE LENGTH(u.id_number) WHEN 18 THEN YEAR(CURRENT_DATE) - SUBSTR(u.id_number, 7, 4) + IF(SUBSTRING_INDEX(CURRENT_DATE,'-',2) - SUBSTR(u.id_number, 11, 4) >0,0,1) WHEN 15 THEN YEAR(CURRENT_DATE) - (SUBSTR(u.id_number, 7, 2) + 1900) + IF(SUBSTRING_INDEX(CURRENT_DATE,'-',2) - SUBSTR(u.id_number, 9, 4) >0,0,1) END age, CASE LENGTH(u.id_number) WHEN 15 THEN IF(MOD(SUBSTR(u.id_number, 15, 1), 2) = 1, '男', '女') WHEN 18 THEN IF(MOD(SUBSTR(u.id_number, 17, 1), 2) = 1, '男', '女') END sex FROM certificates u limit 2,10"

#w_re="SELECT * FROM certificates_display"
#w_re="SELECT CONCAT('{name: \"',LEFT(province,2),'\",value:',total,'}') FROM certificates_display"

def auto():
		conn=MySQLdb.connect(host="localhost",user=str(user1),passwd=str(passwd1),port=3306,db=str(dbname1),read_default_file="/etc/my.cnf",charset="utf8",unix_socket='/tmp/mysql.sock')
                cursor=conn.cursor()
		sql ="SELECT CONCAT('\"',province,'\":',total) FROM certificates_display"
                cursor.execute(sql)
                row = cursor.fetchall()
		cnt = cursor.rowcount
		j = 1
		results = ''
		for i in row:
			result =  i[0]
			if int(cnt) != j:
				results += result + ','
			else:
				end_results = result
			j = j + 1
		
		result =  '{' + results + end_results +'}'
		return eval(result)



