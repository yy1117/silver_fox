#!/usr/bin/python
#-*- coding:utf8 -*-

import sys,os,MySQLdb
reload(sys)
import MySQLdb,re
import ConfigParser #文件解析

def get_config(group,config_name):
    cp = ConfigParser.SafeConfigParser(allow_no_value = True)
    #b = str(os.getcwd())
    b = os.path.abspath('./etc/config.ini')
    cp.readfp(open(b,'rw'))
    config_value=cp.get(group,config_name).strip(' ').strip('\'').strip('\"')
    return config_value


host1  = get_config('monitor_server','host')
port1 = get_config('monitor_server','port')
user1 = get_config('monitor_server','user')
passwd1 = get_config('monitor_server','passwd')
dbname1 = get_config('monitor_server','dbname')



conn1=MySQLdb.connect(host="localhost",user=str(user1),passwd=str(passwd1),port=3306,db=str(dbname1),read_default_file="/etc/my.cnf",charset="utf8",unix_socket='/tmp/mysql.sock')

cursor=conn1.cursor()

def bigtable_dbtb_info(host,index):
	try:
		cursor.execute('SELECT bh.host,CONCAT(bh.db_name,"|",bh.table_name) db_tb_name,DATE(bh.create_time),bh.table_rows FROM mysql_bigtable_history bh WHERE bh.host = "%s" UNION ALL SELECT b.host,CONCAT(b.db_name,"|",b.table_name) db_tb_name,DATE(b.create_time),b.table_rows FROM mysql_bigtable b WHERE b.host = "%s" ' % (host,host))
		row1 = cursor.fetchall()
		
		results = ""
		end_results = ""
		i = 1
		cnt = cursor.rowcount
		#print cnt
		for infor in row1:
			#下面的循环是把每行的记录指定的index位置的值,转换成一行记录(类似列转行)
			if int(cnt) != i:
				results += str(infor[index]) + ','
			else:
				end_results = str(infor[index])
			i = i + 1
		return '"' + results + end_results +'"'

	        #cursor.close()
                #conn1.close()
        except Exception as e:
                print e 

def bigtable_info(host,index):
	try:
		cursor.execute('SELECT bh.host,CONCAT(bh.db_name,"|",bh.table_name) db_tb_name,DATE(bh.create_time),bh.table_rows FROM mysql_bigtable_history bh WHERE bh.host = "%s" UNION ALL SELECT b.host,CONCAT(b.db_name,"|",b.table_name) db_tb_name,DATE(b.create_time),b.table_rows FROM mysql_bigtable b WHERE b.host = "%s" ' % (host,host))
		row1 = cursor.fetchall()
		
		results = ""
		end_results = ""
		i = 1
		#行记录 row_count
		cnt = cursor.rowcount
		#print cnt
		for infor in row1:
			#下面的循环是把每行的记录指定的index位置的值,转换成一行记录(类似列转行)
			if int(cnt) != i:
				results += str(infor[index]) + ','
			else:
				end_results = str(infor[index])
			i = i + 1
		result = results + end_results
		if index == 2:
			results = []
			for i in result.split(','):
				if i not in results:
					results.append(i)
			return results
		elif index == 1:
			db_tb_name=[]
			for j in result.split(','):
				if j not in db_tb_name:
					db_tb_name.append(j)
			#return len(db_tb_name)
			
			xss = ""	
			cnt_db = 1
			for m in db_tb_name:
				dbname = m.split('|')[0]
				tablename = m.split('|')[1]
				cursor.execute('SELECT bh.table_rows FROM mysql_bigtable_history bh WHERE bh.host = "%s" AND bh.db_name="%s" AND bh.table_name="%s" UNION ALL SELECT b.table_rows FROM mysql_bigtable b WHERE b.host = "%s" AND b.db_name="%s" AND b.table_name="%s";' % (host,dbname,tablename,host,dbname,tablename))
				table_rows = cursor.fetchall()	
				cntx = cursor.rowcount
				table_row=[]
				x = 1
				r_result = ""
				rend_result = "" 
				for k in table_rows:
					#table_row.append(k)
					'''
					#字符型
					if int(cntx) != x:
						r_result += str(k[0]) + ','			
					else:
						rend_result = str(k[0])		
					x = x + 1 #本身只有一条数据
					'''
					#整数型
					table_row.append(k[0])
				r_results = table_row
				
				ss = {"name":str(m),"type":"line","data":r_results}
				
				if cnt_db != len(db_tb_name):
					xss += str(ss) + ',' 
				else:
					end_xss =  str(ss)
				cnt_db = cnt_db + 1
			#eval字符串变成 list dict
			return str('[' + xss + end_xss +']').replace('L','').replace("'",'"')
		else:
			return result
		#cursor.close()
		#conn1.close()
	except Exception as e:
		print e	



