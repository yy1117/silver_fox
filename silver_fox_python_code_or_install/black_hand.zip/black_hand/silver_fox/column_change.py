#/usr/bin/python
#-*- coding:utf8 -*-
import sys,os,MySQLdb
reload(sys)
import MySQLdb,re
import ConfigParser 
#path='./include'
#sys.path.insert(0,path)
#import functions as func

def get_config(group,config_name):
    cp = ConfigParser.SafeConfigParser(allow_no_value = True)
    #b = str(os.getcwd())
    b = os.path.abspath('./etc/config.ini')
    #html 报错说目录在/root/csvt01/etc/config.ini 做做了个软连接过去
    cp.readfp(open(b,'rw'))
    config_value=cp.get(group,config_name).strip(' ').strip('\'').strip('\"')
    return config_value


host1  = get_config('monitor_server','host')
port1 = get_config('monitor_server','port')
user1 = get_config('monitor_server','user')
passwd1 = get_config('monitor_server','passwd')
dbname1 = get_config('monitor_server','dbname')

def column_modify_change():
		#conn=MySQLdb.connect(host="localhost",user='root',passwd='root',port=3306,db="django",read_default_file="/etc/my.cnf",charset="utf8",unix_socket='/tmp/mysql.sock')
		conn=MySQLdb.connect(host="localhost",user=str(user1),passwd=str(passwd1),port=3306,db=str(dbname1),read_default_file="/etc/my.cnf",charset="utf8",unix_socket='/tmp/mysql.sock')
                cursor=conn.cursor()
                sql = "SELECT MD5(CONCAT(c.table_name,c.column_name,c.column_type)) column_change_md5 ,MD5(CONCAT(h.table_name,h.column_name,h.column_type )) column_change_history_md5,IF (MD5(CONCAT(c.table_name,c.column_name,c.column_type)) = MD5(CONCAT(h.table_name,h.column_name,h.column_type )),1,0) is_equal,/*CURRENT_DATE() today,*/c.table_name,c.column_name,c.column_type,/*CURRENT_DATE() - INTERVAL  1 DAY yesterday,h.table_name,*/h.column_name,h.column_type FROM column_change c JOIN column_change_history h ON c.table_name= h.table_name  AND /*c.column_name = h.column_name AND*/ c.ordinal_position = h.ordinal_position AND h.host_ip = c.host_ip AND c.table_schema = h.table_schema WHERE  h.host_ip='121.43.199.79' HAVING is_equal <>1"
		cursor.execute(sql)
                row = cursor.fetchall()
		results = []
		for i in row:
			#统计col个数
			cnt_index = len(i)
			cnt = []
			for j in range(cnt_index):
				cnt.append(str(i[j]))
			results.append(cnt)
		return results


def add_column_display():
		#conn=MySQLdb.connect(host="localhost",user='root',passwd='root',port=3306,db="django",read_default_file="/etc/my.cnf",charset="utf8",unix_socket='/tmp/mysql.sock')
		conn=MySQLdb.connect(host="localhost",user=str(user1),passwd=str(passwd1),port=3306,db=str(dbname1),read_default_file="/etc/my.cnf",charset="utf8",unix_socket='/tmp/mysql.sock')
                cursor=conn.cursor()
                sql="SELECT table_schema,table_name,column_name,column_type FROM column_change c WHERE host_ip='121.43.199.79' AND column_name NOT IN (SELECT column_name FROM column_change_history h WHERE host_ip='121.43.199.79'  AND h.table_schema = c.table_schema AND h.table_name=c.table_name) AND column_name NOT IN (SELECT column_name FROM column_change_history h WHERE host_ip='121.43.199.79'  AND h.table_schema = c.table_schema AND c.ordinal_position = h.ordinal_position);"
                cursor.execute(sql)
                row = cursor.fetchall()
		results = []
		for i in row:
			#统计col个数
			cnt_index = len(i)
			cnt = []
			for j in range(cnt_index):
				cnt.append(str(i[j]))
			results.append(cnt)
		return results


def remove_cloumn_display():
		conn=MySQLdb.connect(host="localhost",user=str(user1),passwd=str(passwd1),port=3306,db=str(dbname1),read_default_file="/etc/my.cnf",charset="utf8",unix_socket='/tmp/mysql.sock')
		#conn=MySQLdb.connect(host="localhost",user='root',passwd='root',port=3306,db="django",read_default_file="/etc/my.cnf",charset="utf8",unix_socket='/tmp/mysql.sock')
                cursor=conn.cursor()
                sql="SELECT table_schema,table_name,column_name,column_type FROM column_change_history h WHERE host_ip='121.43.199.79'  AND column_name NOT IN (SELECT column_name FROM column_change c WHERE host_ip='121.43.199.79' AND h.table_schema = c.table_schema AND h.table_name=c.table_name) AND column_name NOT IN (SELECT column_name FROM column_change c WHERE host_ip='121.43.199.79' AND h.table_schema = c.table_schema AND c.ordinal_position = h.ordinal_position);"
                cursor.execute(sql)
                row = cursor.fetchall()
		results = []
		for i in row:
			#统计col个数
			cnt_index = len(i)
			cnt = []
			for j in range(cnt_index):
				cnt.append(str(i[j]))
			results.append(cnt)
		return results


