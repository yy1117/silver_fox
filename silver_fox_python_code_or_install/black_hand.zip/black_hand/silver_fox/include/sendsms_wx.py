#!/usr/bin/env python
#coding:utf-8
 
import sys
import urllib
import urllib2
import time
import json
from optparse import OptionParser
import sys,os 
reload(sys)
sys.setdefaultencoding('utf-8')

def get_token(): 
	corpid = 'wxae5047ebedd51'
	corpsecret = '0g_QZNV3s2746L_Ksm6WBX9d7u72vcXqmqh-bbEPknaQGrIIwhwR8arJ-M'
	#baseurl = 'https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={0}&corpsecret={1}'.format(corpid, corpsecret)
	baseurl = 'https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid='+corpid+'&corpsecret='+corpsecret
	request = urllib2.Request(baseurl)
	respone = urllib2.urlopen(request)
	token_data = respone.read()
	token_json = json.loads(token_data)
	token_json.keys()
	#token = token_json['access_token']
	if 'errcode' in token_json.keys():
		print >> token_json['errmsg'],sys.stderr
		sys.exit(1)
	else:
		token = token_json['access_token']
	return token

#print get_token()

def get_userlist():
	userurl='https://qyapi.weixin.qq.com/cgi-bin/user/simplelist?access_token={0}&department_id=2&fetch_child=1&status=1'.format(get_token())
	request_user = urllib2.Request(userurl)
	respone = urllib2.urlopen(request_user)
	token_user = respone.read()
	token_json_u = json.loads(token_user)
	token_json_u.keys()
	userlist = token_json_u
	#print userlist #get department
	cnt =  len(userlist['userlist'])
	send_userlist = []
	for i in range(0,cnt):
		if i == cnt:
			#打印用户与name
			#print userlist['userlist'][cnt-1]['userid']+','+userlist['userlist'][cnt-1]['name']
			send_userlist.append(userlist['userlist'][cnt-1]['userid']+','+userlist['userlist'][cnt-1]['name'])
		else:
			send_userlist.append(userlist['userlist'][i]['userid']+','+userlist['userlist'][i]['name'])
			#打印用户与name
			#print userlist['userlist'][i]['userid']+','+userlist['userlist'][i]['name']
		i = i + 1
	return	send_userlist

#print get_userlist()
#def send_msg():

#部门ID,第二个函数可以使用
#toparty = 2

def send_wx(wx_to_list,wx_msg,db_type,application,host,port,level,alarm_item,alarm_value,message):
	sendurl='https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={0}'.format(get_token())
	#"touser":'GuiJiaoQi|w121468',"toparty": "2","msgtype": "text","agentid": 1,"text": { "content": "monitor testing department2"},"safe":0}
	wx_to_list_re = str(wx_to_list).replace(',','|')
	send_values={ "touser":wx_to_list_re,"msgtype": "text", 																					  "agentid": 1,                                                                                                                                                               			 "text": { "content": wx_msg},"safe":0}
	send_data = json.dumps(send_values)
	send_request = urllib2.Request(sendurl,send_data)
	send_respone = urllib2.urlopen(send_request)
	send_read = send_respone.read()
	respone = json.loads(send_read)
	return respone


