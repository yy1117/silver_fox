#!/usr/bin/env python
#coding:utf-8
import os
import sys
import string
import time
import datetime
import MySQLdb
path='./include'
sys.path.insert(0,path)
import functions as func
from multiprocessing import Process;

def check_mysql_column(host,port,username,password,server_id,tags):
    try:
        conn=MySQLdb.connect(host=host,user=username,passwd=password,port=int(port),connect_timeout=2,charset='utf8')
        curs=conn.cursor()
        conn.select_db('information_schema')
        try:
           #tablecolumn=curs.execute("select TABLE_SCHEMA,TABLE_NAME,COLUMN_NAME,COLUMN_TYPE from information_schema.COLUMNS where TABLE_SCHEMA not in ('information_schema','performance_schema','sys','test','mysql');");        	
           tablecolumn=curs.execute("SELECT table_schema,table_name,column_name,ordinal_position,is_nullable,column_type,data_type,SUBSTRING_INDEX(REPLACE(column_type,')',''),'(',-1) column_length,character_set_name,column_key,extra FROM information_schema.`COLUMNS` WHERE TABLE_SCHEMA not in ('information_schema','performance_schema','sys','mysql');");
           if tablecolumn:
               for row in curs.fetchall():
                   datalist=[]
                   for r in row:
                      datalist.append(r)
                   result=datalist
		   #判断list是否为空
                   if result:
		       #print result
                       table_schema=result[0]
                       table_name=result[1]
                       column_name=result[2]
                       ordinal_position=result[3]
                       is_nullable=result[4]
                       column_type=result[5]
                       data_type=result[6]
                       column_length=result[7]
                       character_set_name=result[8]
                       column_key=result[9]
                       extra=result[10]
                       #sql="insert into column_change(table_schema,table_name,column_name,column_type) values(%s,%s,%s,%s);"
                       sql="insert into column_change(host_ip,table_schema,table_name,column_name,ordinal_position,is_nullable,column_type,data_type,column_length,character_set_name,column_key,extra) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);"
                       param=(host,result[0],result[1],result[2],result[3],result[4],result[5],result[6],result[7],result[8],result[9],result[10])
		       func.mysql_exec(sql,param)
        except :
	   print 'error'
           pass

        finally:
           curs.close()
           conn.close()
           sys.exit(1)

    except MySQLdb.Error,e:
        pass
        print "Mysql Error %d: %s" %(e.args[0],e.args[1])


def main():
    func.mysql_exec('delete from column_change_history;','')
    func.mysql_exec("insert into column_change_history SELECT * from column_change;",'')
    func.mysql_exec('delete from column_change;','')
    #get mysql servers list
    #servers = func.mysql_query('select id,host,port,username,password,tags from db_servers_mysql where  id in (292,307)')
    servers = func.mysql_query('select id,host,port,username,password,tags from db_servers_mysql;')
    if servers:
        print("%s: check mysql column controller started." % (time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()),));
        plist = []
        for row in servers:
            server_id=row[0]
            host=row[1]
            port=row[2]
            username=row[3]
            password=row[4]
            tags=row[5]
	    #print host,port,username,password,server_id,tags
	    #print check_mysql_column(host,port,username,password,server_id,tags)
	    #check_mysql_column(host,port,username,password,server_id,tags)
	    #这里server_id对应上面定义函数check_mysql_column中间的参数如果修改都需要修改,切记！！！！！！
            #p = Process(target = check_mysql_column, args = (host,port,username,password,server_id,tags))
            p = Process(target = check_mysql_column, args = (host,port,username,password,server_id,tags))
            plist.append(p)
        for p in plist:
            p.start()
        time.sleep(100)
        for p in plist:
            p.terminate()
        for p in plist:
            p.join()
        print("%s: check mysql column controller finished." % (time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()),))
                     

if __name__=='__main__':
    main()

