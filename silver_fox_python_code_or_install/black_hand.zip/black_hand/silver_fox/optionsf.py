#!/usr/bin/python
#-*- coding:utf8 -*-
#namex = sys.argv[1]
import sys,os
reload(sys)
import MySQLdb,re
import ConfigParser #文件解析

def get_config(group,config_name):
    cp = ConfigParser.SafeConfigParser(allow_no_value = True)
    #b = str(os.getcwd())
    b = os.path.abspath('./etc/config.ini')
    #html 报错说目录在/root/csvt01/etc/config.ini 做做了个软连接过去
    cp.readfp(open(b,'rw'))
    config_value=cp.get(group,config_name).strip(' ').strip('\'').strip('\"')
    return config_value

host1  = get_config('monitor_server','host')
port1 = get_config('monitor_server','port')
user1 = get_config('monitor_server','user')
passwd1 = get_config('monitor_server','passwd')
dbname1 = get_config('monitor_server','dbname')

conn1=MySQLdb.connect(host="localhost",user=str(user1),passwd=str(passwd1),port=3306,db=str(dbname1),read_default_file="/etc/my.cnf",charset="utf8",unix_socket='/tmp/mysql.sock')
cursor=conn1.cursor()


#namex = 'GuiJiaoQi'
def opts(namex):
	try:
		cursor.execute('select IF(VALUE="",10000,VALUE) from options where name= "%s" ' % (namex))
		row1 = cursor.fetchall()
		cnt = cursor.rowcount
		if cnt == 0:
			row1 = (0)	
			return (str(row1)+','+str(cnt)).replace('((u\'','').replace('\'),)','').replace('\',',',').replace('u\'','    ').replace(' ','').split(',')	
		else:
			return (str(row1)+','+str(cnt)).replace('((u\'','').replace('\'),)','').replace('\',',',').replace('u\'','').replace(' ','').split(',')
		cursor.close()
		conn1.close()
	except Exception as e:
		print e	



def opts_up(name,value):
	try:
		cursor.execute('update options set value = "%s" where  name= "%s" ' % (value,name))
		conn1.commit()
		return 'updateok'
		cursor.close()
		conn1.close()
	except Exception as e:
		print e
		conn1.rollback()
	 

