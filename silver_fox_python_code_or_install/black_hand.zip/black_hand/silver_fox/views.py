#-*- coding:utf8 -*-
# Create your views here.
from django.http import HttpResponse
#from django.http import JsonResponse
from django.shortcuts import render_to_response
from silver_fox.models import MysqlStatus,ScriptAutoIssuedHostlist
from silver_fox.models import Dbserver,MysqlStatus,MysqlReplication,Backup,DbServersMysql,Options,User,MysqlBigtable,ScriptAutoIssued
from django.template import loader,Context
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.template import RequestContext
import bigtable_trend
import bigtable_trend_group
import tps_qps_display_input_ip
import tps_qps_display
import time

class Person(object):
	def __init__(self,name,age,sex):
		self.name =name
		self.age = age
		self.sex = sex


def index(request):
	user={'user':'Tom','age':28,'name':'Guijiaoqi','sex':'Fale'}
	return render_to_response('index.html',{'title':'My Page','user':user})

def test(request):
	return HttpResponse('<h1>Hello Welcome to Django Word!</h1>')

def first(request):
        ip = request.GET['host']                        
        x_time = bigtable_trend_group.bigtable_info(ip,2)
        y_tb_row = bigtable_trend_group.bigtable_info(ip,1)
        n_data = bigtable_trend_group.bigtable_dbtb_info(ip,1)
        return render_to_response('big_table_analysis_echart_group.html',{'x_time':x_time,'y_select':y_tb_row,'n_data':n_data})


def big_total(request):
	try:
		ip = request.GET['host']
		db = request.GET['db']
		tb = request.GET['tb']
		x_time = bigtable_trend.bigtable_info(ip,db,tb,3)
		y_tb_row = bigtable_trend.bigtable_info(ip,db,tb,4)
		return render_to_response('big_table_analysis_echart.html',{'x_time':x_time,'y_select':y_tb_row,'tb':tb})
	except:
		HttpResponse('<h1>big_total abromal!</h1>')
def search_from(request):
	return render_to_response('search_from.html')


def search(request):
	if 'q' in request.GET:
		message = 'You search for: %r' % request.GET['q']
	else:
		message = 'You submitted an empty from.'
	return HttpResponse(message)



def login(request):
	return render_to_response('login.html',{})


def func(request):
	return render_to_response('func.html',{})




def login_post(request):
	if request.method == 'POST' and request.POST.get('submit') == 'login':
		if request.POST['username'] and request.POST['password']:
			Username =  request.POST['username']
			Password = request.POST['password']
			try :
				passx = User.objects.get(username = request.POST['username'])
			except :
				return render_to_response('login_error.html',{})
			if Username == passx.username  and Password == passx.password:
				#web 调整
				return render_to_response('func.html',{})
			else:
				return render_to_response('login_error.html',{})
		else:
	        	message = 'user is not exists,please retry'
			return HttpResponse(message)


import t_d

def config_center(request):
	results = t_d.get_server_info()
	return render_to_response('22.html',{'results':results})


import big_ana

def big_table_analysis(request):
	
	posts_list = MysqlBigtable.objects.all()
        #####ADD
        page_size=23
        #定义分页，上面的posts_list已经传入这里
        paginator = Paginator(posts_list, page_size)
        try:
                page = int(request.GET.get('page','1'))
        except ValueError:
                page = 1
                print page

        try:
                posts = paginator.page(page)
        except (EmptyPage, InvalidPage):
                posts = paginator.page(paginator.num_pages)

        t = loader.get_template("big_table_analysis.html")
        c = Context({ 'posts' : posts })
        return HttpResponse(t.render(c))	



def db_status(request):
        posts_list =  MysqlStatus.objects.values('host','port','tags','connect','role','uptime','version','threads_connected','threads_running','threads_waits','bytes_received_persecond','bytes_sent_persecond','com_select_persecond')
        #####ADD
        page_size = 9
        #定义分页，上面的posts_list已经传入这里
        paginator = Paginator(posts_list, page_size)
        try:
                page = int(request.GET.get('page','1'))
        except ValueError:
                page = 1
                print page

        try:
                posts = paginator.page(page)
        except (EmptyPage, InvalidPage):
                posts = paginator.page(paginator.num_pages)
        #####ADD

        t = loader.get_template("db_status.html")
        c = Context({ 'posts' : posts })
        return HttpResponse(t.render(c))



def options(request):
	return render_to_response('monitor_sendwx_options.html',{})


def dbserver_list_new(request):
	return render_to_response('dbserver_list_new.html',{})


def dbserver_list(request):
	######分页######
        posts_list =  Dbserver.objects.all()

        #####ADD
        page_size = 20
        #定义分页，上面的posts_list已经传入这里
        paginator = Paginator(posts_list, page_size)
        try:
                page = int(request.GET.get('page','1'))
        except ValueError:
                page = 1
                print page

        try:
                posts = paginator.page(page)
        except (EmptyPage, InvalidPage):
                posts = paginator.page(paginator.num_pages)
        #####ADD

        #t = loader.get_template("limit.html")
        t = loader.get_template("dbserver_list.html")
        c = Context({ 'posts' : posts })
        return HttpResponse(t.render(c))

def dbserver_form(request):
	if request.GET.get('submit') == 'addserver':
		return render_to_response('dbserver_form.html',{})
	else:
	        id = request.GET.get("id")
        	server_id = request.GET.get("server_id")
       		host = request.GET.get("host")
        	port = request.GET.get("port")
        	tag = request.GET.get("tag")
        	edite = request.GET.get("edite")
		return render_to_response('dbserver_form.html',{"id":id,"server_id":server_id,"host":host,"port":port,"tag":tag,"edite":edite})

def _update(request):
	xid = request.GET["id"]
	xport = request.GET["port"]
	xserver_id = request.GET["server_id"]
	xhost = request.GET["host"]
	xtag = request.GET['tag']
	xedite = request.GET['edite']
	#单条数据修改
	dbserverlist1 = Dbserver.objects.get( id = xid )
	dbserverlist1.port = xport
	dbserverlist1.server_id = xserver_id
	dbserverlist1.tag = xtag
	dbserverlist1.host = xhost
	dbserverlist1.edite = xedite
	dbserverlist1.save()
	return render_to_response('dbserver_form.html',{"id":xid,"server_id":xserver_id,"host":xhost,"port":xport,"tag":xtag,"edite":xedite})	



def _delete(request):
        xid = request.GET["id"]
        xport = request.GET["port"]
        xserver_id = request.GET["server_id"]
        xhost = request.GET["host"]
        xtag = request.GET['tag']
        xedite = request.GET['edite']
        dbserverlist = Dbserver.objects.get( id = xid )
	dbserverlist.delete()
        return render_to_response('dbserver_form.html',{"id":xid,"server_id":xserver_id,"host":xhost,"port":xport,"tag":xtag,"edite":xedite})



import optionsf
def _insert(request):
	if request.method == 'POST' and request.POST.get('submit') == 'add_host_info':
		host = request.POST.get('host')
		username = request.POST.get('username')
		password = request.POST.get('password')
		
		if  host =="" or username =="" or password =="":
			return render_to_response('dbserver_list_new.html',{})
		else:
               		dbservermysql = DbServersMysql(
				host=request.POST.get('host'),port=request.POST.get('port'),username=request.POST.get('username'),
				password=request.POST.get('password'),tags=request.POST.get('tags'),monitor=request.POST.get('monitor'),
				send_mail=request.POST.get('send_mail'),send_mail_to_list=request.POST.get('send_mail_to_list'),
				send_sms=request.POST.get('send_sms'),
				send_sms_to_list=request.POST.get('send_sms_to_list'),
				send_wx=request.POST.get('send_wx'),
				send_wx_to_list=request.POST.get('send_wx_to_list'),
				slow_query=request.POST.get('slow_query'),
				send_slowquery_to_list=request.POST.get('send_slowquery_to_list'),
				bigtable_monitor=request.POST.get('bigtable_monitor'),binlog_auto_purge=request.POST.get('binlog_auto_purge'),
				binlog_store_days=request.POST.get('binlog_store_days'),
				alarm_threads_connected=request.POST.get('alarm_threads_connected'),
				threshold_warning_threads_connected=request.POST.get('threshold_warning_threads_connected'),
				threshold_critical_threads_connected=request.POST.get('threshold_critical_threads_connected'),
				alarm_threads_running=request.POST.get('alarm_threads_running'),
				threshold_warning_threads_running=request.POST.get('threshold_warning_threads_running'),
				threshold_critical_threads_running=request.POST.get('threshold_critical_threads_running'),
				alarm_threads_waits=request.POST.get('alarm_threads_waits'),
				threshold_warning_threads_waits=request.POST.get('threshold_warning_threads_waits'),
				threshold_critical_threads_waits=request.POST.get('threshold_critical_threads_waits'),
				alarm_repl_status=request.POST.get('alarm_repl_status'),
				alarm_repl_delay=request.POST.get('alarm_repl_delay'),
				threshold_warning_repl_delay=request.POST.get('threshold_warning_repl_delay'),
				threshold_critical_repl_delay=request.POST.get('threshold_critical_repl_delay'),
				repl_channel=request.POST.get('repl_channel'),
				bigtable_size=50,is_delete=0,display_order=0,
				create_time=time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(time.time())))

			dbservermysql.save()
                	return render_to_response('dbserver_list_new.html',{})

	elif request.method == 'POST' and request.POST.get('submit') == 'save_monitor_switch':
		
		monitor_values=['monitor','monitor_mysql','send_alarm_mail','send_mail_to_list','monitor_os',
				'monitor_mongodb','alarm','send_mail_max_count','frequency_monitor','send_mail_sleep_time',
				'mailtype','mailprotocol','smtp_host','smtp_port','smtp_user','smtp_pass','smtp_timeout',
				'mailfrom','monitor_redis','send_alarm_sms','send_sms_to_list','send_sms_max_count',
				'send_sms_sleep_time','smstype','send_alarm_wx','send_wx_max_count',
				'send_wx_sleep_time','send_wx_to_list','wxtype','send_alarm_dingding','send_dingding_max_count',
				'send_dingding_sleep_time','send_dingding_to_list']
		
	
		monitor_values_des={
		'monitor':'是否开启全局监控,此项如果关闭则所有项目都不会被监控，下面监控选项都失效',
		'monitor_mysql':'是否开启MySQL状态监控','send_alarm_mail':'是否发送报警邮件',
		'send_mail_to_list':'报警邮件通知人员','monitor_os':'是否开启OS监控','monitor_mongodb':'是否监控MongoDB',
		'alarm':'是否开启告警','send_mail_max_count':'发送邮件最大次数','report_mail_to_list':'报告邮件推送接收人员',
		'frequency_monitor':'监控频率','send_mail_sleep_time':'发送邮件休眠时间(分钟)','mailtype':'邮件发送配置:邮件类型',
		'mailprotocol':'邮件发送配置:邮件协议','smtp_host':'邮件发送配置:邮件主机','smtp_port':'邮件发送配置:邮件端口',
		'smtp_user':'邮件发送配置:用户','smtp_pass':'邮件发送配置:密码','smtp_timeout':'邮件发送配置:超时时间',
		'mailfrom':'邮件发送配置:发件人','monitor_redis':'是否监控Redis','monitor_oracle':'是否监控Oracle',
		'send_alarm_sms':'是否发生短信','send_sms_to_list':'短信收件人列表','send_sms_max_count':'发送短信最大次数',
		'send_sms_sleep_time':'发送短信休眠时间(分钟)','smstype':'发送短信方式：fetion/api',
		'send_alarm_wx':'是否发生微信','send_wx_max_count':'发送微信最大次数',
		'send_wx_sleep_time':'发送微信休眠时间(分钟)','send_wx_to_list':'微信收件人列表','wxtype':'发送告警方式：weixin',
		'send_alarm_dingding':'是否发送钉钉','send_dingding_max_count':'发送钉钉最大次数',
		'send_dingding_sleep_time':'发送告警钉钉消息休眠时间','send_dingding_to_list':'告警钉钉消息收件人列表'
		}

		j = int(len(monitor_values))
		 
		for i in range(0,int(j)):
			if i < int(j) : 	
				namex = optionsf.opts(monitor_values[i])[0]
				cntx = optionsf.opts(monitor_values[i])[-1]
				if int(cntx) == 0 :
			                dbmonitor_options = Options(
                                                name=monitor_values[i],
                                                value=request.POST.get(monitor_values[i]),
                                                description=monitor_values_des[monitor_values[i]])
                                        dbmonitor_options.save()							
				else:	
					if str(namex)  ==  str(request.POST.get(monitor_values[i])):
						pass
					elif  str(namex) !=  str(request.POST.get(monitor_values[i])):
						optionsf.opts_up(monitor_values[i],str(request.POST.get(monitor_values[i])))	
			i = i + 1
		return render_to_response('monitor_sendwx_options.html',{})
	elif request.method == 'GET':	
		dbservermysql = DbServersMysql(
			host=request.GET.get('host'),port=request.GET.get('port'),username=request.GET.get('username'),
			password=request.GET.get('password'),tags=request.GET.get('tags'),monitor=request.GET.get('monitor'),
			send_mail=request.GET.get('send_mail'),send_mail_to_list=request.GET.get('send_mail_to_list'),
			send_sms=request.GET.get('send_sms'),
			send_sms_to_list=request.GET.get('send_sms_to_list'),
			send_wx=request.POST.get('send_wx'),
                        send_wx_to_list=request.POST.get('send_wx_to_list'),
			slow_query=request.GET.get('slow_query'),
			send_slowquery_to_list=request.GET.get('send_slowquery_to_list'),
			bigtable_monitor=request.GET.get('bigtable_monitor'),binlog_auto_purge=request.GET.get('binlog_auto_purge'),
			binlog_store_days=request.GET.get('binlog_store_days'),
			alarm_threads_connected=request.GET.get('alarm_threads_connected'),
			threshold_warning_threads_connected=request.GET.get('threshold_warning_threads_connected'),
			threshold_critical_threads_connected=request.GET.get('threshold_critical_threads_connected'),
			alarm_threads_running=request.GET.get('alarm_threads_running'),
			threshold_warning_threads_running=request.GET.get('threshold_warning_threads_running'),
			threshold_critical_threads_running=request.GET.get('threshold_critical_threads_running'),
			alarm_threads_waits=request.GET.get('alarm_threads_waits'),
			threshold_warning_threads_waits=request.GET.get('threshold_warning_threads_waits'),
			threshold_critical_threads_waits=request.GET.get('threshold_critical_threads_waits'),
			alarm_repl_status=request.GET.get('alarm_repl_status'),
			alarm_repl_delay=request.GET.get('alarm_repl_delay'),
			threshold_warning_repl_delay=request.GET.get('threshold_warning_repl_delay'),
			threshold_critical_repl_delay=request.GET.get('threshold_critical_repl_delay'),
			repl_channel=request.GET.get('repl_channel'),
			bigtable_size=50,is_delete=0,display_order=0,
			create_time=time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(time.time()))
	  		)
		
        	dbservermysql.save()
		return render_to_response('dbserver_form.html',{})	
	else:
		if request.GET.get('port') :
        		xport = request.GET["port"]
        		xserver_id = request.GET["server_id"]
       			xhost = request.GET["host"]
        		xtag = request.GET['tag']
        		xedite = request.GET['edite']
			#单条数据写入
        		dbserverlist = Dbserver(server_id=xserver_id,host=xhost,port=xport,tag=xtag,edite=xedite)
        		dbserverlist.save()	
        		return render_to_response('dbserver_form.html',{"server_id":xserver_id,"host":xhost,"port":xport,"tag":xtag,"edite":xedite})
		else:
			return render_to_response('dbserver_form.html',{})


import json
def echarts(request):
	t = loader.get_template("column_echarts.html")
	categories = "衬衫,羊毛衫,雪纺衫,裤子,高跟鞋,袜子,短袖"
	data = [15, 120, 136, 110, 110, 120,500]
	c = Context({ 'name_dict' : data,'categories':categories})
	return HttpResponse(t.render(c))

def ajax_dict(request):
	 try:	
		ip = request.GET['chart']
		x_time = tps_qps_display_input_ip.get_server_info(ip,1)
                y_select = tps_qps_display_input_ip.get_server_info(ip,2)
                y_insert = tps_qps_display_input_ip.get_server_info(ip,3)
                y_update = tps_qps_display_input_ip.get_server_info(ip,4)
                y_delete = tps_qps_display_input_ip.get_server_info(ip,5)
                #tps qps 处理
                y_questions = tps_qps_display_input_ip.get_server_info(ip,6)
                y_tps = tps_qps_display_input_ip.get_server_info(ip,7)
                #commit/rollback
                y_com_commit = tps_qps_display_input_ip.get_server_info(ip,8)
                y_com_rollback = tps_qps_display_input_ip.get_server_info(ip,9)
                #thread
                y_threads_connected = tps_qps_display_input_ip.get_server_info(ip,10)
                y_threads_running = tps_qps_display_input_ip.get_server_info(ip,11)

                #logic or physical
                y_innodb_buffer_pool_read_requests_persecond = tps_qps_display_input_ip.get_server_info(ip,13)
                y_innodb_buffer_pool_reads_persecond = tps_qps_display_input_ip.get_server_info(ip,14)

                #row_read,row_insert,row_update,row_delete
                y_innodb_rows_read_persecond = tps_qps_display_input_ip.get_server_info(ip,15)
                y_innodb_rows_inserted_persecond = tps_qps_display_input_ip.get_server_info(ip,16)
                y_innodb_rows_updated_persecond = tps_qps_display_input_ip.get_server_info(ip,17)
                y_innodb_rows_deleted_persecond = tps_qps_display_input_ip.get_server_info(ip,18)

      		data = "15, 120, 136, 110, 110, 120,500"
        	categories = "Sun,Mon,Tue,Wed,Thu,Fri,Sat"
                return render_to_response('straig_echarts.html',{'title':'My Page','x_time':x_time,'y_select':y_select,'y_insert':y_insert,'y_update':y_update,'y_delete':y_delete,'y_questions':y_questions,'y_tps':y_tps,'y_com_commit':y_com_commit,'y_com_rollback':y_com_rollback,'y_threads_connected':y_threads_connected,'y_threads_running':y_threads_running,'y_innodb_buffer_pool_read_requests_persecond':y_innodb_buffer_pool_read_requests_persecond,'y_innodb_buffer_pool_reads_persecond':y_innodb_buffer_pool_reads_persecond,'y_innodb_rows_read_persecond':y_innodb_rows_read_persecond,'y_innodb_rows_inserted_persecond':y_innodb_rows_inserted_persecond,'y_innodb_rows_updated_persecond':y_innodb_rows_updated_persecond,'y_innodb_rows_deleted_persecond':y_innodb_rows_deleted_persecond,'categories':categories,'data':data})	
	 except:
	 		return HttpResponse('<h1>loading data fail</h1>')	


import china_map
def pie_echarts(request):
	china_mapx = china_map.auto()	
	return render_to_response('straig_chaina_map.html',{'citys':china_mapx})
	


def db_replica(request):
	
	posts_list =  MysqlReplication.objects.values('host','port','tags','is_slave','delay').filter(is_slave__gt = 0)

        #####ADD
        page_size = 20
	paginator = Paginator(posts_list, page_size)
        try:
                page = int(request.GET.get('page','1'))
        except ValueError:
                page = 1
                print page

        try:
                posts = paginator.page(page)
        except (EmptyPage, InvalidPage):
                posts = paginator.page(paginator.num_pages)
        #####ADD

        t = loader.get_template("replication.html")
        c = Context({ 'posts' : posts })
        return HttpResponse(t.render(c))





def db_backup(request):
        #分页
        #posts_list =  MysqlReplication.objects.all()
        posts_list =  Backup.objects.values('ipaddress','host_name','file_size','frequency_name','start_time','database_name','end_time').order_by('-id')

        #####ADD
        page_size = 13
        paginator = Paginator(posts_list, page_size)
        try:
                page = int(request.GET.get('page','1'))
        except ValueError:
                page = 1
                print page
        try:
                posts = paginator.page(page)
        except (EmptyPage, InvalidPage):
                posts = paginator.page(paginator.num_pages)
        #####ADD
        t = loader.get_template("backup.html")
        c = Context({ 'posts' : posts })
        return HttpResponse(t.render(c))

import MySQLdb,sys,os,re
import auto_sql
def auto(request):
   try:	
	if 'send_script' in request.GET :
		if request.GET['send_script'] == 'other':
			ip = os.popen("ifconfig eth0|grep inet|awk -F' ' '{print $2}'|awk -F':' '{print $2}'").readlines()[0].strip('\n')
			return render_to_response('auto.html',{'ip':ip})
		else:
			return render_to_response('auto.html',{})
	
	elif 'wb' in request.GET:
		wb = '%r' % request.GET['wb']
		w_re1 = re.sub('limit.+\d+','',wb)
		if 'limit' or 'LIMIT' in wb:
			w_re = str(w_re1.replace('\\r\\n','').replace('u\'','').replace('\'','').replace(';','')) + ' limit 10;' 
		else:
			w_re = str(wb.replace('\\r\\n','').replace('u\'','').replace('\'','').replace(';','')) +' limit 10;'
		
		if 'select' or 'SELECT' in wb:
			row = auto_sql.auto(w_re)
			return render_to_response('auto.html',{'E_SQL':w_re,'row':row})
		else:
			return render_to_response('auto.html',{})
	else:
		return render_to_response('auto.html',{})
   except:
	#return HttpResponse('SQL_Abnormal')
	w_re='SQL_Abnormal'
	return render_to_response('auto.html',{'E_SQL':w_re})
	#return render_to_response('auto.html',{})

import auto_sql_senior
def auto_senior(request):
   try:
	if request.method == 'POST' and request.POST.get('search') == 'submit_sql': 
		if request.POST.get('hosts') and request.POST.get('dbs') and request.POST.get('wb'):
			
			wb = '%r' % request.POST.get('wb')
               		w_re1 = re.sub('limit.+\d+','',wb)
			shost = request.POST.get('hosts')
			sdb = request.POST.get('dbs')
			
                	if 'select' or 'SELECT' in wb:
                        	row = auto_sql_senior.auto(shost,sdb,request.POST.get('wb'))
				#ip display
				rows = auto_sql_senior.auto_selected(0) 
				#db display
				sdbs = auto_sql_senior.auto_selected(4)
                        	return render_to_response('auto_senior.html',{'E_SQL':request.POST.get('wb'),'row':row,'rows':rows,'sdbs':sdbs})
                	else:
                		return render_to_response('auto_senior.html',{'rows':rows,'sdbs':sdbs})
		else:
		
			rows = auto_sql_senior.auto_selected(0)
			sdbs = auto_sql_senior.auto_selected(4) 
                	return render_to_response('auto_senior.html',{'rows':rows,'sdbs':sdbs})
        else:
		rows = auto_sql_senior.auto_selected(0)
		sdbs = auto_sql_senior.auto_selected(4) 
                return render_to_response('auto_senior.html',{'rows':rows,'sdbs':sdbs})
   except:

        w_re='SQL_Abnormal'
	rows = auto_sql_senior.auto_selected(0)
	sdbs = auto_sql_senior.auto_selected(4)
        return render_to_response('auto_senior.html',{'E_SQL':w_re,'rows':rows,'sdbs':sdbs})

	

def db_auto_install(request):
		#指定列
		#指定下发脚本名称
		rows = ScriptAutoIssued.objects.values("issued_button").all()
		rows_issued_button = []
		for i in range(0,len(rows)):
			rows_issued_button.append(rows[i]['issued_button'])

		#指定下发主机组	
		rows_groups = ScriptAutoIssuedHostlist.objects.values('ansible_host_group').all()	
		rows_groups_list = []
		for j in range(0,len(rows_groups)):
			rows_groups_list.append(rows_groups[j]['ansible_host_group'])

	        if request.GET.get('send_scripts') and request.GET.get('host_groups'):
                	if request.GET['send_scripts'] == 'command_exec':
				ip = os.popen("ifconfig eth0|grep inet|awk -F' ' '{print $2}'|awk -F':' '{print $2}'").readlines()[0].strip('\n')
                        	return render_to_response('db_auto_install.html',{'ip':ip,'rows':rows_issued_button,'group_host':rows_groups_list})

			elif request.GET['send_scripts'] and str(request.GET['exec_scripts']) != str(1):
				hosts_groups = str(request.GET.get('host_groups'))
				#注意空格
				script_path_ = ScriptAutoIssued.objects.get(issued_button = request.GET['send_scripts'])
				script_path_exec = script_path_.script_path
				#testing script_name_is_ok
				ip = os.popen('ansible '+ hosts_groups +' -m copy -a "src='+ script_path_exec  +' dest=/root"').readlines()
				return render_to_response('db_auto_install.html',{'ip':ip,'rows':rows_issued_button,'group_host':rows_groups_list})
			elif request.GET['send_scripts'] and str(request.GET['exec_scripts']) == str(1):
				hosts_groups = str(request.GET.get('host_groups'))
				script_path_ = ScriptAutoIssued.objects.get(issued_button = request.GET['send_scripts'])
				script_path_exec = script_path_.script_path
				#defautls file save remote host /root/.ansible/tmp
				ip = os.popen('ansible '+ hosts_groups +' -m script -a " '+ script_path_exec  +' >/tmp/scripts.log"').readlines()
				return render_to_response('db_auto_install.html',{'ip':ip,'rows':rows_issued_button,'group_host':rows_groups_list})
			else:
				return render_to_response('db_auto_install.html',{'rows':rows_issued_button,'group_host':rows_groups_list})
                else:
                        	return render_to_response('db_auto_install.html',{'rows':rows_issued_button,'group_host':rows_groups_list})


import column_change
def column_change_recored(request):
	posts = column_change.column_modify_change()
	add_column = column_change.add_column_display()
	remove_column = column_change.remove_cloumn_display()
	return render_to_response('column_modify.html',{'add_column':add_column,'remove_column':remove_column,'posts':posts})



'''
#测试分页页面
def list(request):
	posts_list =  Dbserver.objects.all()
	
	#####ADD
	page_size=2
	#定义分页，上面的posts_list已经传入这里
	paginator = Paginator(posts_list, page_size)
	try:
		page = int(request.GET.get('page','1'))
	except ValueError:
		page = 1
		print page
	
	try:
		posts = paginator.page(page)
	except (EmptyPage, InvalidPage):
		posts = paginator.page(paginator.num_pages)			
	#####ADD
	
	t = loader.get_template("limit.html")
	c = Context({ 'posts' : posts })
	return HttpResponse(t.render(c))
'''
