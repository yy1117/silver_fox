#-*- coding:utf8 -*-
import MySQLdb,re,os
import sys
reload(sys)
import MySQLdb,re
import ConfigParser #文件解析



def get_config(group,config_name):
    cp = ConfigParser.SafeConfigParser(allow_no_value = True)
    b = os.path.abspath('./etc/config.ini')
    cp.readfp(open(b,'rw'))
    config_value=cp.get(group,config_name).strip(' ').strip('\'').strip('\"')
    return config_value


host1  = get_config('monitor_server','host')
port1 = get_config('monitor_server','port')
user1 = get_config('monitor_server','user')
passwd1 = get_config('monitor_server','passwd')
dbname1 = get_config('monitor_server','dbname')



def auto(shost,sdb,w_re):
		users = auto_selected_new(shost,sdb,2)[0]	
		passwds = auto_selected_new(shost,sdb,3)[0]
                conn=MySQLdb.connect(host=shost,user=str(users),passwd=str(passwds),port=3306,db=sdb,read_default_file="/etc/my.cnf",charset="utf8",unix_socket='/tmp/mysql.sock')
		#指定db
		#conn.select_db('information_schema'
		
		xlimit = 'limit 10'	
                cursor=conn.cursor()
		if 'limit' or 'LIMIT' in w_re:
			w_re2 = re.sub(';','',w_re)
			w_re1 = re.sub('limit.+\d+','',w_re2)
			
			sql= w_re1 + ' '+ xlimit
		else:
			w_re2 = re.sub(';','',w_re)
                	sql = w_re2 +' ' +xlimit
		#print sql
                cursor.execute(sql)
                row = cursor.fetchall()
		results = []
		n = ''
		for i in row:
			#统计col个数
			cnt_index = len(i)
			cnt = []
			for j in range(cnt_index):
				cnt.append(i[j])
			results.append(cnt)
		return results
		cursor.close()
		conn.close()

#select db,host
def auto_selected_new(hostx,dbx,index):
                conn=MySQLdb.connect(host=str(host1),user=str(user1),passwd=str(passwd1),port=int(port1),db=str(dbname1),read_default_file="/etc/my.cnf",charset="utf8",unix_socket='/tmp/mysql.sock')
                #指定db
                cursor=conn.cursor()
                cursor.execute('SELECT HOST,tags,username,PASSWORD,dbname FROM auto_senior where host="%s" and dbname="%s" ' % (hostx,dbx))
                row = cursor.fetchall()
                results = []
                n = ''
                for i in row:
                        #统计col个数
                        cnt_index = len(i)
			if i[index] not in results:
				results.append(str(i[index]))
			'''
                        cnt = []
                        for j in range(cnt_index):
                                #print str([j])
                                cnt.append(str(i[j]))
                        #print cnt
                        results.append(cnt)
                        #print len(results[0].keys()),results[0].keys(),'\n'
			'''
                return results
                cursor.close()
                conn.close()



def auto_selected(index):
                conn=MySQLdb.connect(host=str(host1),user=str(user1),passwd=str(passwd1),port=int(port1),db=str(dbname1),read_default_file="/etc/my.cnf",charset="utf8",unix_socket='/tmp/mysql.sock')
                #指定db
                #conn.select_db('information_schema')   
                cursor=conn.cursor()
                sql = 'SELECT HOST,tags,username,PASSWORD,dbname FROM auto_senior ;'
                cursor.execute(sql)
                row = cursor.fetchall()
                results = []
                n = ''
                for i in row:
                        #统计col个数
                        cnt_index = len(i)
                        if i[index] not in results:
                                results.append(str(i[index]))
                
		return results
                cursor.close()
                conn.close()




