# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
#
# Also note: You'll have to insert the output of 'django-admin sqlcustom [app_label]'
# into your database.
from __future__ import unicode_literals

from django.db import models


class Alarm(models.Model):
    server_id = models.SmallIntegerField()
    tags = models.CharField(max_length=50, blank=True, null=True)
    host = models.CharField(max_length=30, blank=True, null=True)
    port = models.CharField(max_length=10, blank=True, null=True)
    create_time = models.DateTimeField(blank=True, null=True)
    db_type = models.CharField(max_length=30, blank=True, null=True)
    alarm_item = models.CharField(max_length=50, blank=True, null=True)
    alarm_value = models.CharField(max_length=50, blank=True, null=True)
    level = models.CharField(max_length=50, blank=True, null=True)
    message = models.CharField(max_length=255, blank=True, null=True)
    send_mail = models.IntegerField(blank=True, null=True)
    send_mail_to_list = models.CharField(max_length=255, blank=True, null=True)
    send_sms = models.IntegerField(blank=True, null=True)
    send_sms_to_list = models.CharField(max_length=255, blank=True, null=True)
    send_wx = models.IntegerField(blank=True, null=True)
    send_wx_to_list = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'alarm'


class AlarmHistory(models.Model):
    server_id = models.SmallIntegerField()
    tags = models.CharField(max_length=50, blank=True, null=True)
    host = models.CharField(max_length=30, blank=True, null=True)
    port = models.CharField(max_length=10, blank=True, null=True)
    create_time = models.DateTimeField(blank=True, null=True)
    db_type = models.CharField(max_length=30, blank=True, null=True)
    alarm_item = models.CharField(max_length=50, blank=True, null=True)
    alarm_value = models.CharField(max_length=50, blank=True, null=True)
    level = models.CharField(max_length=50, blank=True, null=True)
    message = models.CharField(max_length=255, blank=True, null=True)
    send_mail = models.IntegerField(blank=True, null=True)
    send_mail_to_list = models.CharField(max_length=255, blank=True, null=True)
    send_sms = models.IntegerField(blank=True, null=True)
    send_sms_to_list = models.CharField(max_length=255, blank=True, null=True)
    send_mail_status = models.IntegerField()
    send_sms_status = models.IntegerField()
    send_wx = models.IntegerField(blank=True, null=True)
    send_wx_to_list = models.CharField(max_length=255, blank=True, null=True)
    send_wx_status = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'alarm_history'


class AlarmTemp(models.Model):
    server_id = models.SmallIntegerField()
    ip = models.CharField(max_length=50, blank=True, null=True)
    db_type = models.CharField(max_length=30, blank=True, null=True)
    alarm_item = models.CharField(max_length=50, blank=True, null=True)
    alarm_type = models.CharField(max_length=30, blank=True, null=True)
    create_time = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'alarm_temp'


class AuthGroup(models.Model):
    name = models.CharField(unique=True, max_length=80)

    class Meta:
        managed = False
        db_table = 'auth_group'


class AuthGroupPermissions(models.Model):
    group = models.ForeignKey(AuthGroup)
    permission = models.ForeignKey('AuthPermission')

    class Meta:
        managed = False
        db_table = 'auth_group_permissions'
        unique_together = (('group', 'permission'),)


class AuthMessage(models.Model):
    user = models.ForeignKey('AuthUser')
    message = models.TextField()

    class Meta:
        managed = False
        db_table = 'auth_message'


class AuthPermission(models.Model):
    name = models.CharField(max_length=50)
    content_type = models.ForeignKey('DjangoContentType')
    codename = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'auth_permission'
        unique_together = (('content_type', 'codename'),)


class AuthUser(models.Model):
    username = models.CharField(unique=True, max_length=30)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    email = models.CharField(max_length=75)
    password = models.CharField(max_length=128)
    is_staff = models.IntegerField()
    is_active = models.IntegerField()
    is_superuser = models.IntegerField()
    last_login = models.DateTimeField()
    date_joined = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'auth_user'


class AuthUserGroups(models.Model):
    user = models.ForeignKey(AuthUser)
    group = models.ForeignKey(AuthGroup)

    class Meta:
        managed = False
        db_table = 'auth_user_groups'
        unique_together = (('user', 'group'),)


class AuthUserUserPermissions(models.Model):
    user = models.ForeignKey(AuthUser)
    permission = models.ForeignKey(AuthPermission)

    class Meta:
        managed = False
        db_table = 'auth_user_user_permissions'
        unique_together = (('user', 'permission'),)


class AutoSenior(models.Model):
    host = models.CharField(max_length=100, blank=True, null=True)
    tags = models.CharField(max_length=100, blank=True, null=True)
    username = models.CharField(max_length=50, blank=True, null=True)
    password = models.CharField(max_length=50, blank=True, null=True)
    dbname = models.CharField(max_length=20, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'auto_senior'


class Backup(models.Model):
    ipaddress = models.CharField(max_length=30, blank=True, null=True)
    host_name = models.CharField(max_length=50, blank=True, null=True)
    file_size = models.BigIntegerField()
    backup_status = models.IntegerField()
    start_time = models.DateTimeField()
    database_name = models.CharField(max_length=20)
    frequency_name = models.CharField(max_length=20)
    end_time = models.DateTimeField()
    create_time = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'backup'


class BinlogDml(models.Model):
    host = models.CharField(max_length=50, blank=True, null=True)
    port = models.IntegerField(blank=True, null=True)
    tags = models.CharField(max_length=50, blank=True, null=True)
    binlog_name = models.CharField(max_length=100, blank=True, null=True)
    binlog_size = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'binlog_dml'


class BlogUser(models.Model):
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)

    class Meta:
        managed = False
        db_table = 'blog_user'


class Certificates(models.Model):
    user_id = models.BigIntegerField(primary_key=True)
    id_number = models.CharField(max_length=32)
    id_card = models.CharField(max_length=120)
    real_name = models.CharField(max_length=16, blank=True, null=True)
    create_time = models.BigIntegerField()
    update_time = models.BigIntegerField()
    type = models.SmallIntegerField(blank=True, null=True)
    real_user_id = models.BigIntegerField()

    class Meta:
        managed = False
        db_table = 'certificates'


class CertificatesDisplay(models.Model):
    province = models.CharField(max_length=8, blank=True, null=True)
    total = models.BigIntegerField()

    class Meta:
        managed = False
        db_table = 'certificates_display'


class ColumnChange(models.Model):
    host_ip = models.CharField(max_length=60)
    table_schema = models.CharField(max_length=60)
    table_name = models.CharField(max_length=60)
    column_name = models.CharField(max_length=60)
    ordinal_position = models.CharField(max_length=11)
    is_nullable = models.CharField(max_length=6)
    column_type = models.CharField(max_length=60)
    data_type = models.CharField(max_length=60)
    column_length = models.CharField(max_length=60)
    character_set_name = models.CharField(max_length=60, blank=True, null=True)
    column_key = models.CharField(max_length=60, blank=True, null=True)
    extra = models.CharField(max_length=60, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'column_change'


class ColumnChangeHistory(models.Model):
    host_ip = models.CharField(max_length=60)
    table_schema = models.CharField(max_length=60)
    table_name = models.CharField(max_length=60)
    column_name = models.CharField(max_length=60)
    ordinal_position = models.CharField(max_length=11)
    is_nullable = models.CharField(max_length=6)
    column_type = models.CharField(max_length=60)
    data_type = models.CharField(max_length=60)
    column_length = models.CharField(max_length=60)
    character_set_name = models.CharField(max_length=60, blank=True, null=True)
    column_key = models.CharField(max_length=60, blank=True, null=True)
    extra = models.CharField(max_length=60, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'column_change_history'


class DbServerInfo(models.Model):
    server_id = models.IntegerField()
    host = models.CharField(max_length=20)
    port = models.IntegerField()
    tag = models.CharField(max_length=30, blank=True, null=True)
    edite = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'db_server_info'


class DbServersMongodb(models.Model):
    host = models.CharField(max_length=30)
    port = models.CharField(max_length=10)
    username = models.CharField(max_length=50, blank=True, null=True)
    password = models.CharField(max_length=50, blank=True, null=True)
    tags = models.CharField(max_length=50, blank=True, null=True)
    monitor = models.IntegerField(blank=True, null=True)
    send_mail = models.IntegerField(blank=True, null=True)
    send_mail_to_list = models.CharField(max_length=255, blank=True, null=True)
    send_sms = models.IntegerField(blank=True, null=True)
    send_sms_to_list = models.CharField(max_length=255, blank=True, null=True)
    alarm_connections_current = models.IntegerField()
    alarm_active_clients = models.IntegerField()
    alarm_current_queue = models.IntegerField()
    threshold_warning_connections_current = models.IntegerField()
    threshold_warning_active_clients = models.SmallIntegerField()
    threshold_warning_current_queue = models.SmallIntegerField()
    threshold_critical_connections_current = models.IntegerField()
    threshold_critical_active_clients = models.SmallIntegerField()
    threshold_critical_current_queue = models.SmallIntegerField()
    is_delete = models.IntegerField()
    display_order = models.SmallIntegerField()
    create_time = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'db_servers_mongodb'


class DbServersMysql(models.Model):
    host = models.CharField(max_length=30)
    port = models.CharField(max_length=10)
    username = models.CharField(max_length=30, blank=True, null=True)
    password = models.CharField(max_length=30, blank=True, null=True)
    tags = models.CharField(max_length=50, blank=True, null=True)
    monitor = models.IntegerField(blank=True, null=True)
    send_mail = models.IntegerField(blank=True, null=True)
    send_mail_to_list = models.CharField(max_length=255, blank=True, null=True)
    send_sms = models.IntegerField(blank=True, null=True)
    send_sms_to_list = models.CharField(max_length=255, blank=True, null=True)
    send_wx = models.IntegerField(blank=True, null=True)
    send_wx_to_list = models.CharField(max_length=255, blank=True, null=True)
    send_slowquery_to_list = models.CharField(max_length=255, blank=True, null=True)
    alarm_threads_connected = models.IntegerField(blank=True, null=True)
    alarm_threads_running = models.IntegerField(blank=True, null=True)
    alarm_threads_waits = models.IntegerField(blank=True, null=True)
    alarm_repl_status = models.IntegerField(blank=True, null=True)
    alarm_repl_delay = models.IntegerField(blank=True, null=True)
    threshold_warning_threads_connected = models.IntegerField(blank=True, null=True)
    threshold_warning_threads_running = models.IntegerField(blank=True, null=True)
    threshold_warning_threads_waits = models.IntegerField(blank=True, null=True)
    threshold_warning_repl_delay = models.IntegerField(blank=True, null=True)
    threshold_critical_threads_connected = models.IntegerField(blank=True, null=True)
    threshold_critical_threads_running = models.IntegerField(blank=True, null=True)
    threshold_critical_threads_waits = models.IntegerField(blank=True, null=True)
    threshold_critical_repl_delay = models.IntegerField(blank=True, null=True)
    slow_query = models.IntegerField()
    binlog_auto_purge = models.IntegerField()
    binlog_store_days = models.SmallIntegerField()
    bigtable_monitor = models.IntegerField()
    bigtable_size = models.IntegerField()
    is_delete = models.IntegerField()
    display_order = models.SmallIntegerField()
    create_time = models.DateTimeField(blank=True, null=True)
    repl_channel = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'db_servers_mysql'


class DbServersOracle(models.Model):
    host = models.CharField(max_length=30, blank=True, null=True)
    port = models.CharField(max_length=10, blank=True, null=True)
    dsn = models.CharField(max_length=50, blank=True, null=True)
    username = models.CharField(max_length=50, blank=True, null=True)
    password = models.CharField(max_length=100, blank=True, null=True)
    tags = models.CharField(max_length=100, blank=True, null=True)
    monitor = models.IntegerField(blank=True, null=True)
    send_mail = models.IntegerField(blank=True, null=True)
    send_mail_to_list = models.CharField(max_length=255, blank=True, null=True)
    send_sms = models.IntegerField(blank=True, null=True)
    send_sms_to_list = models.CharField(max_length=255, blank=True, null=True)
    alarm_session_total = models.IntegerField()
    alarm_session_actives = models.IntegerField()
    alarm_session_waits = models.IntegerField()
    alarm_tablespace = models.IntegerField()
    threshold_warning_session_total = models.SmallIntegerField()
    threshold_warning_session_actives = models.SmallIntegerField()
    threshold_warning_session_waits = models.IntegerField()
    threshold_warning_tablespace = models.SmallIntegerField()
    threshold_critical_session_total = models.SmallIntegerField()
    threshold_critical_session_actives = models.SmallIntegerField()
    threshold_critical_session_waits = models.SmallIntegerField()
    threshold_critical_tablespace = models.SmallIntegerField()
    is_delete = models.IntegerField()
    display_order = models.SmallIntegerField()
    create_time = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'db_servers_oracle'


class DbServersOs(models.Model):
    host = models.CharField(max_length=30, blank=True, null=True)
    community = models.CharField(max_length=50, blank=True, null=True)
    tags = models.CharField(max_length=30, blank=True, null=True)
    monitor = models.IntegerField(blank=True, null=True)
    send_mail = models.IntegerField(blank=True, null=True)
    send_mail_to_list = models.CharField(max_length=255, blank=True, null=True)
    send_sms = models.IntegerField(blank=True, null=True)
    send_sms_to_list = models.CharField(max_length=255, blank=True, null=True)
    alarm_os_process = models.IntegerField()
    alarm_os_load = models.IntegerField()
    alarm_os_cpu = models.IntegerField()
    alarm_os_network = models.IntegerField()
    alarm_os_disk = models.IntegerField()
    alarm_os_memory = models.IntegerField()
    threshold_warning_os_process = models.IntegerField()
    threshold_warning_os_load = models.IntegerField()
    threshold_warning_os_cpu = models.IntegerField()
    threshold_warning_os_network = models.IntegerField()
    threshold_warning_os_disk = models.IntegerField()
    threshold_warning_os_memory = models.IntegerField()
    threshold_critical_os_process = models.IntegerField()
    threshold_critical_os_load = models.IntegerField()
    threshold_critical_os_cpu = models.IntegerField()
    threshold_critical_os_network = models.IntegerField()
    threshold_critical_os_disk = models.IntegerField()
    threshold_critical_os_memory = models.IntegerField()
    filter_os_disk = models.CharField(max_length=100, blank=True, null=True)
    is_delete = models.IntegerField()
    display_order = models.SmallIntegerField()
    remark = models.CharField(max_length=1000, blank=True, null=True)
    create_time = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'db_servers_os'


class DbServersRedis(models.Model):
    host = models.CharField(max_length=30)
    port = models.CharField(max_length=10)
    password = models.CharField(max_length=50, blank=True, null=True)
    tags = models.CharField(max_length=50, blank=True, null=True)
    monitor = models.IntegerField(blank=True, null=True)
    send_mail = models.IntegerField(blank=True, null=True)
    send_mail_to_list = models.CharField(max_length=255, blank=True, null=True)
    send_sms = models.IntegerField(blank=True, null=True)
    send_sms_to_list = models.CharField(max_length=255, blank=True, null=True)
    alarm_connected_clients = models.IntegerField()
    alarm_command_processed = models.IntegerField()
    alarm_blocked_clients = models.IntegerField()
    threshold_warning_connected_clients = models.IntegerField()
    threshold_warning_command_processed = models.IntegerField()
    threshold_warning_blocked_clients = models.SmallIntegerField()
    threshold_critical_connected_clients = models.IntegerField()
    threshold_critical_command_processed = models.IntegerField()
    threshold_critical_blocked_clients = models.SmallIntegerField()
    is_delete = models.IntegerField()
    display_order = models.SmallIntegerField()
    create_time = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'db_servers_redis'


class DbStatus(models.Model):
    server_id = models.SmallIntegerField()
    host = models.CharField(max_length=30)
    port = models.CharField(max_length=10)
    db_type = models.CharField(max_length=10)
    db_type_sort = models.IntegerField()
    tags = models.CharField(max_length=50)
    role = models.CharField(max_length=30)
    version = models.CharField(max_length=30)
    connect = models.IntegerField()
    connect_tips = models.CharField(max_length=500)
    sessions = models.IntegerField()
    sessions_tips = models.CharField(max_length=500)
    actives = models.IntegerField()
    actives_tips = models.CharField(max_length=500)
    waits = models.IntegerField()
    waits_tips = models.CharField(max_length=500)
    repl = models.IntegerField()
    repl_tips = models.CharField(max_length=500)
    repl_delay = models.IntegerField()
    repl_delay_tips = models.CharField(max_length=500)
    tablespace = models.IntegerField()
    tablespace_tips = models.CharField(max_length=500)
    snmp = models.IntegerField()
    snmp_tips = models.CharField(max_length=500)
    process = models.IntegerField()
    process_tips = models.CharField(max_length=500)
    load_1 = models.IntegerField()
    load_1_tips = models.CharField(max_length=500)
    cpu = models.IntegerField()
    cpu_tips = models.CharField(max_length=500)
    network = models.IntegerField()
    network_tips = models.CharField(max_length=500)
    memory = models.IntegerField()
    memory_tips = models.CharField(max_length=500)
    disk = models.IntegerField()
    disk_tips = models.CharField(max_length=500)
    uptime_time = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'db_status'


class Dbserver(models.Model):
    server_id = models.IntegerField()
    host = models.CharField(max_length=20)
    port = models.IntegerField()
    tag = models.CharField(max_length=40)
    edite = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'dbserver'


class DjangoAdminLog(models.Model):
    action_time = models.DateTimeField()
    user = models.ForeignKey(AuthUser)
    content_type = models.ForeignKey('DjangoContentType', blank=True, null=True)
    object_id = models.TextField(blank=True, null=True)
    object_repr = models.CharField(max_length=200)
    action_flag = models.SmallIntegerField()
    change_message = models.TextField()

    class Meta:
        managed = False
        db_table = 'django_admin_log'


class DjangoContentType(models.Model):
    name = models.CharField(max_length=100)
    app_label = models.CharField(max_length=100)
    model = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'django_content_type'
        unique_together = (('app_label', 'model'),)


class DjangoMigrations(models.Model):
    app = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    applied = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_migrations'


class DjangoSession(models.Model):
    session_key = models.CharField(primary_key=True, max_length=40)
    session_data = models.TextField()
    expire_date = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_session'


class DjangoSite(models.Model):
    domain = models.CharField(max_length=100)
    name = models.CharField(max_length=50)

    class Meta:
        managed = False
        db_table = 'django_site'


class LepusStatus(models.Model):
    lepus_variables = models.CharField(max_length=255)
    lepus_value = models.CharField(max_length=255)

    class Meta:
        managed = False
        db_table = 'lepus_status'


class MongodbStatus(models.Model):
    server_id = models.SmallIntegerField()
    host = models.CharField(max_length=50)
    port = models.CharField(max_length=30)
    tags = models.CharField(max_length=50, blank=True, null=True)
    connect = models.SmallIntegerField()
    replset = models.SmallIntegerField()
    repl_role = models.CharField(max_length=30)
    ok = models.IntegerField()
    uptime = models.IntegerField()
    version = models.CharField(max_length=50)
    connections_current = models.SmallIntegerField()
    connections_available = models.BigIntegerField()
    globallock_currentqueue = models.SmallIntegerField(db_column='globalLock_currentQueue')  # Field name made lowercase.
    globallock_activeclients = models.SmallIntegerField(db_column='globalLock_activeClients')  # Field name made lowercase.
    indexcounters_accesses = models.BigIntegerField(db_column='indexCounters_accesses')  # Field name made lowercase.
    indexcounters_hits = models.BigIntegerField(db_column='indexCounters_hits')  # Field name made lowercase.
    indexcounters_misses = models.BigIntegerField(db_column='indexCounters_misses')  # Field name made lowercase.
    indexcounters_resets = models.IntegerField(db_column='indexCounters_resets')  # Field name made lowercase.
    indexcounters_missratio = models.CharField(db_column='indexCounters_missRatio', max_length=10)  # Field name made lowercase.
    cursors_totalopen = models.SmallIntegerField(db_column='cursors_totalOpen')  # Field name made lowercase.
    cursors_timeout = models.IntegerField(db_column='cursors_timeOut')  # Field name made lowercase.
    dur_commits = models.SmallIntegerField()
    dur_journaledmb = models.CharField(db_column='dur_journaledMB', max_length=30)  # Field name made lowercase.
    dur_writetodatafilesmb = models.CharField(db_column='dur_writeToDataFilesMB', max_length=30)  # Field name made lowercase.
    dur_compression = models.CharField(max_length=30)
    dur_commitsinwritelock = models.SmallIntegerField(db_column='dur_commitsInWriteLock')  # Field name made lowercase.
    dur_earlycommits = models.SmallIntegerField(db_column='dur_earlyCommits')  # Field name made lowercase.
    dur_timems_dt = models.SmallIntegerField(db_column='dur_timeMs_dt')  # Field name made lowercase.
    dur_timems_preplogbuffer = models.SmallIntegerField(db_column='dur_timeMs_prepLogBuffer')  # Field name made lowercase.
    dur_timems_writetojournal = models.SmallIntegerField(db_column='dur_timeMs_writeToJournal')  # Field name made lowercase.
    dur_timems_writetodatafiles = models.SmallIntegerField(db_column='dur_timeMs_writeToDataFiles')  # Field name made lowercase.
    dur_timems_remapprivateview = models.SmallIntegerField(db_column='dur_timeMs_remapPrivateView')  # Field name made lowercase.
    mem_bits = models.SmallIntegerField()
    mem_resident = models.IntegerField()
    mem_virtual = models.IntegerField()
    mem_supported = models.CharField(max_length=10)
    mem_mapped = models.IntegerField()
    mem_mappedwithjournal = models.IntegerField(db_column='mem_mappedWithJournal')  # Field name made lowercase.
    network_bytesin_persecond = models.IntegerField(db_column='network_bytesIn_persecond')  # Field name made lowercase.
    network_bytesout_persecond = models.IntegerField(db_column='network_bytesOut_persecond')  # Field name made lowercase.
    network_numrequests_persecond = models.IntegerField(db_column='network_numRequests_persecond')  # Field name made lowercase.
    opcounters_insert_persecond = models.SmallIntegerField()
    opcounters_query_persecond = models.SmallIntegerField()
    opcounters_update_persecond = models.SmallIntegerField()
    opcounters_delete_persecond = models.SmallIntegerField()
    opcounters_command_persecond = models.SmallIntegerField()
    create_time = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'mongodb_status'


class MongodbStatusHistory(models.Model):
    server_id = models.SmallIntegerField()
    host = models.CharField(max_length=50)
    port = models.CharField(max_length=30)
    tags = models.CharField(max_length=50, blank=True, null=True)
    connect = models.SmallIntegerField()
    replset = models.IntegerField()
    repl_role = models.CharField(max_length=30)
    ok = models.IntegerField()
    uptime = models.IntegerField()
    version = models.CharField(max_length=50)
    connections_current = models.SmallIntegerField()
    connections_available = models.BigIntegerField()
    globallock_currentqueue = models.SmallIntegerField(db_column='globalLock_currentQueue')  # Field name made lowercase.
    globallock_activeclients = models.SmallIntegerField(db_column='globalLock_activeClients')  # Field name made lowercase.
    indexcounters_accesses = models.BigIntegerField(db_column='indexCounters_accesses')  # Field name made lowercase.
    indexcounters_hits = models.BigIntegerField(db_column='indexCounters_hits')  # Field name made lowercase.
    indexcounters_misses = models.BigIntegerField(db_column='indexCounters_misses')  # Field name made lowercase.
    indexcounters_resets = models.IntegerField(db_column='indexCounters_resets')  # Field name made lowercase.
    indexcounters_missratio = models.CharField(db_column='indexCounters_missRatio', max_length=10)  # Field name made lowercase.
    cursors_totalopen = models.SmallIntegerField(db_column='cursors_totalOpen')  # Field name made lowercase.
    cursors_timeout = models.IntegerField(db_column='cursors_timeOut')  # Field name made lowercase.
    dur_commits = models.SmallIntegerField()
    dur_journaledmb = models.CharField(db_column='dur_journaledMB', max_length=30)  # Field name made lowercase.
    dur_writetodatafilesmb = models.CharField(db_column='dur_writeToDataFilesMB', max_length=30)  # Field name made lowercase.
    dur_compression = models.CharField(max_length=30)
    dur_commitsinwritelock = models.SmallIntegerField(db_column='dur_commitsInWriteLock')  # Field name made lowercase.
    dur_earlycommits = models.SmallIntegerField(db_column='dur_earlyCommits')  # Field name made lowercase.
    dur_timems_dt = models.SmallIntegerField(db_column='dur_timeMs_dt')  # Field name made lowercase.
    dur_timems_preplogbuffer = models.SmallIntegerField(db_column='dur_timeMs_prepLogBuffer')  # Field name made lowercase.
    dur_timems_writetojournal = models.SmallIntegerField(db_column='dur_timeMs_writeToJournal')  # Field name made lowercase.
    dur_timems_writetodatafiles = models.SmallIntegerField(db_column='dur_timeMs_writeToDataFiles')  # Field name made lowercase.
    dur_timems_remapprivateview = models.SmallIntegerField(db_column='dur_timeMs_remapPrivateView')  # Field name made lowercase.
    mem_bits = models.SmallIntegerField()
    mem_resident = models.IntegerField()
    mem_virtual = models.IntegerField()
    mem_supported = models.CharField(max_length=10)
    mem_mapped = models.IntegerField()
    mem_mappedwithjournal = models.IntegerField(db_column='mem_mappedWithJournal')  # Field name made lowercase.
    network_bytesin_persecond = models.IntegerField(db_column='network_bytesIn_persecond')  # Field name made lowercase.
    network_bytesout_persecond = models.IntegerField(db_column='network_bytesOut_persecond')  # Field name made lowercase.
    network_numrequests_persecond = models.IntegerField(db_column='network_numRequests_persecond')  # Field name made lowercase.
    opcounters_insert_persecond = models.SmallIntegerField()
    opcounters_query_persecond = models.SmallIntegerField()
    opcounters_update_persecond = models.SmallIntegerField()
    opcounters_delete_persecond = models.SmallIntegerField()
    opcounters_command_persecond = models.SmallIntegerField()
    create_time = models.DateTimeField()
    ymdhi = models.BigIntegerField(db_column='YmdHi')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'mongodb_status_history'


class MysqlBigtable(models.Model):
    server_id = models.SmallIntegerField(blank=True, null=True)
    host = models.CharField(max_length=30)
    port = models.CharField(max_length=10)
    tags = models.CharField(max_length=50)
    db_name = models.CharField(max_length=50, blank=True, null=True)
    table_name = models.CharField(max_length=100, blank=True, null=True)
    table_size = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    table_comment = models.CharField(max_length=200, blank=True, null=True)
    create_time = models.DateTimeField(blank=True, null=True)
    table_rows = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'mysql_bigtable'


class MysqlBigtableHistory(models.Model):
    server_id = models.SmallIntegerField(blank=True, null=True)
    host = models.CharField(max_length=30)
    port = models.CharField(max_length=10)
    tags = models.CharField(max_length=50)
    db_name = models.CharField(max_length=50, blank=True, null=True)
    table_name = models.CharField(max_length=100, blank=True, null=True)
    table_size = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    table_comment = models.CharField(max_length=200, blank=True, null=True)
    create_time = models.DateTimeField(blank=True, null=True)
    table_rows = models.IntegerField(blank=True, null=True)
    ymd = models.IntegerField(db_column='Ymd', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'mysql_bigtable_history'


class MysqlConnected(models.Model):
    server_id = models.SmallIntegerField()
    host = models.CharField(max_length=30)
    port = models.CharField(max_length=10)
    tags = models.CharField(max_length=50)
    connect_server = models.CharField(max_length=100)
    connect_user = models.CharField(max_length=50, blank=True, null=True)
    connect_db = models.CharField(max_length=50, blank=True, null=True)
    connect_count = models.IntegerField()
    create_time = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'mysql_connected'


class MysqlProcesslist(models.Model):
    server_id = models.SmallIntegerField(blank=True, null=True)
    host = models.CharField(max_length=30)
    port = models.CharField(max_length=10)
    tags = models.CharField(max_length=50)
    pid = models.IntegerField(blank=True, null=True)
    p_user = models.CharField(max_length=50, blank=True, null=True)
    p_host = models.CharField(max_length=50, blank=True, null=True)
    p_db = models.CharField(max_length=30, blank=True, null=True)
    command = models.CharField(max_length=30, blank=True, null=True)
    time = models.CharField(max_length=200)
    status = models.CharField(max_length=50, blank=True, null=True)
    info = models.TextField(blank=True, null=True)
    create_time = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'mysql_processlist'


class MysqlReplication(models.Model):
    server_id = models.SmallIntegerField(blank=True, null=True)
    tags = models.CharField(max_length=50)
    host = models.CharField(max_length=30, blank=True, null=True)
    port = models.CharField(max_length=20, blank=True, null=True)
    is_master = models.IntegerField(blank=True, null=True)
    is_slave = models.IntegerField(blank=True, null=True)
    read_only = models.CharField(max_length=10, blank=True, null=True)
    gtid_mode = models.CharField(max_length=10, blank=True, null=True)
    master_server = models.CharField(max_length=30, blank=True, null=True)
    master_port = models.CharField(max_length=20, blank=True, null=True)
    slave_io_run = models.CharField(max_length=20, blank=True, null=True)
    slave_sql_run = models.CharField(max_length=20, blank=True, null=True)
    delay = models.CharField(max_length=20, blank=True, null=True)
    current_binlog_file = models.CharField(max_length=30, blank=True, null=True)
    current_binlog_pos = models.CharField(max_length=30, blank=True, null=True)
    master_binlog_file = models.CharField(max_length=30, blank=True, null=True)
    master_binlog_pos = models.CharField(max_length=30, blank=True, null=True)
    master_binlog_space = models.BigIntegerField()
    slave_sql_running_state = models.CharField(db_column='Slave_SQL_Running_State', max_length=100, blank=True, null=True)  # Field name made lowercase.
    create_time = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'mysql_replication'


class MysqlReplicationHistory(models.Model):
    server_id = models.SmallIntegerField()
    tags = models.CharField(max_length=50)
    host = models.CharField(max_length=30, blank=True, null=True)
    port = models.CharField(max_length=20, blank=True, null=True)
    is_master = models.IntegerField(blank=True, null=True)
    is_slave = models.IntegerField(blank=True, null=True)
    read_only = models.CharField(max_length=10, blank=True, null=True)
    gtid_mode = models.CharField(max_length=10, blank=True, null=True)
    master_server = models.CharField(max_length=30, blank=True, null=True)
    master_port = models.CharField(max_length=20, blank=True, null=True)
    slave_io_run = models.CharField(max_length=20, blank=True, null=True)
    slave_sql_run = models.CharField(max_length=20, blank=True, null=True)
    delay = models.CharField(max_length=20, blank=True, null=True)
    current_binlog_file = models.CharField(max_length=30, blank=True, null=True)
    current_binlog_pos = models.CharField(max_length=30, blank=True, null=True)
    master_binlog_file = models.CharField(max_length=30, blank=True, null=True)
    master_binlog_pos = models.CharField(max_length=30, blank=True, null=True)
    master_binlog_space = models.BigIntegerField(blank=True, null=True)
    slave_sql_running_state = models.CharField(db_column='Slave_SQL_Running_State', max_length=100, blank=True, null=True)  # Field name made lowercase.
    create_time = models.DateTimeField(blank=True, null=True)
    ymdhi = models.BigIntegerField(db_column='YmdHi', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'mysql_replication_history'


class MysqlStatus(models.Model):
    server_id = models.SmallIntegerField()
    host = models.CharField(max_length=30)
    port = models.CharField(max_length=10)
    tags = models.CharField(max_length=50)
    connect = models.SmallIntegerField()
    role = models.CharField(max_length=30)
    uptime = models.IntegerField()
    version = models.CharField(max_length=50)
    max_connections = models.SmallIntegerField()
    max_connect_errors = models.IntegerField()
    open_files_limit = models.IntegerField()
    open_files = models.SmallIntegerField()
    table_open_cache = models.SmallIntegerField()
    open_tables = models.SmallIntegerField()
    max_tmp_tables = models.SmallIntegerField()
    max_heap_table_size = models.IntegerField()
    max_allowed_packet = models.IntegerField()
    threads_connected = models.IntegerField()
    threads_running = models.IntegerField()
    threads_waits = models.IntegerField()
    threads_created = models.IntegerField()
    threads_cached = models.IntegerField()
    connections = models.IntegerField()
    aborted_clients = models.IntegerField()
    aborted_connects = models.IntegerField()
    connections_persecond = models.SmallIntegerField()
    bytes_received_persecond = models.IntegerField()
    bytes_sent_persecond = models.IntegerField()
    com_select_persecond = models.SmallIntegerField()
    com_insert_persecond = models.SmallIntegerField()
    com_update_persecond = models.SmallIntegerField()
    com_delete_persecond = models.SmallIntegerField()
    com_commit_persecond = models.SmallIntegerField()
    com_rollback_persecond = models.SmallIntegerField()
    questions_persecond = models.IntegerField()
    queries_persecond = models.IntegerField()
    transaction_persecond = models.SmallIntegerField()
    created_tmp_tables_persecond = models.SmallIntegerField()
    created_tmp_disk_tables_persecond = models.SmallIntegerField()
    created_tmp_files_persecond = models.SmallIntegerField()
    table_locks_immediate_persecond = models.IntegerField()
    table_locks_waited_persecond = models.SmallIntegerField()
    key_buffer_size = models.BigIntegerField()
    sort_buffer_size = models.IntegerField()
    join_buffer_size = models.IntegerField()
    key_blocks_not_flushed = models.IntegerField()
    key_blocks_unused = models.IntegerField()
    key_blocks_used = models.IntegerField()
    key_read_requests_persecond = models.IntegerField()
    key_reads_persecond = models.IntegerField()
    key_write_requests_persecond = models.IntegerField()
    key_writes_persecond = models.IntegerField()
    innodb_version = models.CharField(max_length=30)
    innodb_buffer_pool_instances = models.SmallIntegerField()
    innodb_buffer_pool_size = models.BigIntegerField()
    innodb_doublewrite = models.CharField(max_length=10)
    innodb_file_per_table = models.CharField(max_length=10)
    innodb_flush_log_at_trx_commit = models.IntegerField()
    innodb_flush_method = models.CharField(max_length=30)
    innodb_force_recovery = models.IntegerField()
    innodb_io_capacity = models.IntegerField()
    innodb_read_io_threads = models.IntegerField()
    innodb_write_io_threads = models.IntegerField()
    innodb_buffer_pool_pages_total = models.IntegerField()
    innodb_buffer_pool_pages_data = models.IntegerField()
    innodb_buffer_pool_pages_dirty = models.IntegerField()
    innodb_buffer_pool_pages_flushed = models.BigIntegerField()
    innodb_buffer_pool_pages_free = models.IntegerField()
    innodb_buffer_pool_pages_misc = models.BigIntegerField(blank=True, null=True)
    innodb_page_size = models.IntegerField()
    innodb_pages_created = models.BigIntegerField()
    innodb_pages_read = models.BigIntegerField()
    innodb_pages_written = models.BigIntegerField()
    innodb_row_lock_current_waits = models.CharField(max_length=100)
    innodb_buffer_pool_pages_flushed_persecond = models.IntegerField()
    innodb_buffer_pool_read_requests_persecond = models.IntegerField()
    innodb_buffer_pool_reads_persecond = models.IntegerField()
    innodb_buffer_pool_write_requests_persecond = models.IntegerField()
    innodb_rows_read_persecond = models.IntegerField()
    innodb_rows_inserted_persecond = models.IntegerField()
    innodb_rows_updated_persecond = models.IntegerField()
    innodb_rows_deleted_persecond = models.IntegerField()
    query_cache_hitrate = models.CharField(max_length=10)
    thread_cache_hitrate = models.CharField(max_length=10)
    key_buffer_read_rate = models.CharField(max_length=10)
    key_buffer_write_rate = models.CharField(max_length=10)
    key_blocks_used_rate = models.CharField(max_length=10)
    created_tmp_disk_tables_rate = models.CharField(max_length=10)
    connections_usage_rate = models.CharField(max_length=10)
    open_files_usage_rate = models.CharField(max_length=10)
    open_tables_usage_rate = models.CharField(max_length=10)
    create_time = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'mysql_status'


class MysqlStatusHistory(models.Model):
    server_id = models.SmallIntegerField()
    host = models.CharField(max_length=30)
    port = models.CharField(max_length=10)
    tags = models.CharField(max_length=50)
    connect = models.SmallIntegerField()
    role = models.CharField(max_length=30)
    uptime = models.IntegerField()
    version = models.CharField(max_length=50)
    max_connections = models.SmallIntegerField()
    max_connect_errors = models.IntegerField()
    open_files_limit = models.IntegerField()
    open_files = models.SmallIntegerField()
    table_open_cache = models.SmallIntegerField()
    open_tables = models.SmallIntegerField()
    max_tmp_tables = models.SmallIntegerField()
    max_heap_table_size = models.IntegerField()
    max_allowed_packet = models.IntegerField()
    threads_connected = models.IntegerField()
    threads_running = models.IntegerField()
    threads_waits = models.IntegerField()
    threads_created = models.IntegerField()
    threads_cached = models.IntegerField()
    connections = models.IntegerField()
    aborted_clients = models.IntegerField()
    aborted_connects = models.IntegerField()
    connections_persecond = models.SmallIntegerField()
    bytes_received_persecond = models.IntegerField()
    bytes_sent_persecond = models.IntegerField()
    com_select_persecond = models.SmallIntegerField()
    com_insert_persecond = models.SmallIntegerField()
    com_update_persecond = models.SmallIntegerField()
    com_delete_persecond = models.SmallIntegerField()
    com_commit_persecond = models.SmallIntegerField()
    com_rollback_persecond = models.SmallIntegerField()
    questions_persecond = models.IntegerField()
    queries_persecond = models.IntegerField()
    transaction_persecond = models.SmallIntegerField()
    created_tmp_tables_persecond = models.SmallIntegerField()
    created_tmp_disk_tables_persecond = models.SmallIntegerField()
    created_tmp_files_persecond = models.SmallIntegerField()
    table_locks_immediate_persecond = models.IntegerField()
    table_locks_waited_persecond = models.SmallIntegerField()
    key_buffer_size = models.BigIntegerField()
    sort_buffer_size = models.IntegerField()
    join_buffer_size = models.IntegerField()
    key_blocks_not_flushed = models.IntegerField()
    key_blocks_unused = models.IntegerField()
    key_blocks_used = models.IntegerField()
    key_read_requests_persecond = models.IntegerField()
    key_reads_persecond = models.IntegerField()
    key_write_requests_persecond = models.IntegerField()
    key_writes_persecond = models.IntegerField()
    innodb_version = models.CharField(max_length=30)
    innodb_buffer_pool_instances = models.SmallIntegerField()
    innodb_buffer_pool_size = models.BigIntegerField()
    innodb_doublewrite = models.CharField(max_length=10)
    innodb_file_per_table = models.CharField(max_length=10)
    innodb_flush_log_at_trx_commit = models.IntegerField()
    innodb_flush_method = models.CharField(max_length=30)
    innodb_force_recovery = models.IntegerField()
    innodb_io_capacity = models.IntegerField()
    innodb_read_io_threads = models.IntegerField()
    innodb_write_io_threads = models.IntegerField()
    innodb_buffer_pool_pages_total = models.IntegerField()
    innodb_buffer_pool_pages_data = models.IntegerField()
    innodb_buffer_pool_pages_dirty = models.IntegerField()
    innodb_buffer_pool_pages_flushed = models.BigIntegerField()
    innodb_buffer_pool_pages_free = models.IntegerField()
    innodb_buffer_pool_pages_misc = models.BigIntegerField(blank=True, null=True)
    innodb_page_size = models.IntegerField()
    innodb_pages_created = models.BigIntegerField()
    innodb_pages_read = models.BigIntegerField()
    innodb_pages_written = models.BigIntegerField()
    innodb_row_lock_current_waits = models.CharField(max_length=100)
    innodb_buffer_pool_pages_flushed_persecond = models.IntegerField()
    innodb_buffer_pool_read_requests_persecond = models.IntegerField()
    innodb_buffer_pool_reads_persecond = models.IntegerField()
    innodb_buffer_pool_write_requests_persecond = models.IntegerField()
    innodb_rows_read_persecond = models.IntegerField()
    innodb_rows_inserted_persecond = models.IntegerField()
    innodb_rows_updated_persecond = models.IntegerField()
    innodb_rows_deleted_persecond = models.IntegerField()
    query_cache_hitrate = models.CharField(max_length=20, blank=True, null=True)
    thread_cache_hitrate = models.CharField(max_length=10)
    key_buffer_read_rate = models.CharField(max_length=10)
    key_buffer_write_rate = models.CharField(max_length=10)
    key_blocks_used_rate = models.CharField(max_length=10)
    created_tmp_disk_tables_rate = models.CharField(max_length=10)
    connections_usage_rate = models.CharField(max_length=10)
    open_files_usage_rate = models.CharField(max_length=10)
    open_tables_usage_rate = models.CharField(max_length=10)
    create_time = models.DateTimeField()
    ymdhi = models.BigIntegerField(db_column='YmdHi')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'mysql_status_history'


class Options(models.Model):
    name = models.CharField(max_length=150, blank=True, null=True)
    value = models.CharField(max_length=765, blank=True, null=True)
    description = models.CharField(max_length=300, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'options'


class Options20161130(models.Model):
    name = models.CharField(max_length=150, blank=True, null=True)
    value = models.CharField(max_length=765, blank=True, null=True)
    description = models.CharField(max_length=300, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'options_20161130'


class OracleStatus(models.Model):
    server_id = models.SmallIntegerField()
    host = models.CharField(max_length=50)
    port = models.CharField(max_length=10)
    tags = models.CharField(max_length=100, blank=True, null=True)
    connect = models.IntegerField()
    instance_name = models.CharField(max_length=30)
    instance_role = models.CharField(max_length=50)
    instance_status = models.CharField(max_length=50)
    database_role = models.CharField(max_length=50)
    open_mode = models.CharField(max_length=30)
    protection_mode = models.CharField(max_length=30)
    host_name = models.CharField(max_length=50)
    database_status = models.CharField(max_length=30)
    startup_time = models.CharField(max_length=100)
    uptime = models.CharField(max_length=100)
    version = models.CharField(max_length=50)
    archiver = models.CharField(max_length=50)
    session_total = models.IntegerField()
    session_actives = models.SmallIntegerField()
    session_waits = models.SmallIntegerField()
    dg_stats = models.CharField(max_length=255)
    dg_delay = models.IntegerField()
    processes = models.IntegerField()
    session_logical_reads_persecond = models.IntegerField()
    physical_reads_persecond = models.IntegerField()
    physical_writes_persecond = models.IntegerField()
    physical_read_io_requests_persecond = models.IntegerField()
    physical_write_io_requests_persecond = models.IntegerField()
    db_block_changes_persecond = models.IntegerField()
    os_cpu_wait_time = models.IntegerField()
    logons_persecond = models.IntegerField()
    logons_current = models.IntegerField()
    opened_cursors_persecond = models.IntegerField()
    opened_cursors_current = models.IntegerField()
    user_commits_persecond = models.IntegerField()
    user_rollbacks_persecond = models.IntegerField()
    user_calls_persecond = models.IntegerField()
    db_block_gets_persecond = models.IntegerField()
    create_time = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'oracle_status'


class OracleTablespace(models.Model):
    server_id = models.SmallIntegerField()
    host = models.CharField(max_length=50)
    port = models.CharField(max_length=30)
    tags = models.CharField(max_length=50)
    tablespace_name = models.CharField(max_length=100)
    total_size = models.BigIntegerField()
    used_size = models.BigIntegerField()
    avail_size = models.BigIntegerField()
    used_rate = models.CharField(max_length=255)
    create_time = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'oracle_tablespace'


class OsDisk(models.Model):
    ip = models.CharField(max_length=50)
    tags = models.CharField(max_length=100, blank=True, null=True)
    mounted = models.CharField(max_length=50)
    total_size = models.BigIntegerField()
    used_size = models.BigIntegerField()
    avail_size = models.BigIntegerField()
    used_rate = models.CharField(max_length=255)
    create_time = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'os_disk'


class OsDiskHistory(models.Model):
    ip = models.CharField(max_length=50)
    tags = models.CharField(max_length=100, blank=True, null=True)
    mounted = models.CharField(max_length=50)
    total_size = models.BigIntegerField()
    used_size = models.BigIntegerField()
    avail_size = models.BigIntegerField()
    used_rate = models.CharField(max_length=255)
    create_time = models.DateTimeField()
    ymdhi = models.BigIntegerField(db_column='YmdHi')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'os_disk_history'


class OsDiskio(models.Model):
    ip = models.CharField(max_length=50)
    tags = models.CharField(max_length=100, blank=True, null=True)
    fdisk = models.CharField(max_length=50)
    disk_io_reads = models.BigIntegerField()
    disk_io_writes = models.BigIntegerField()
    create_time = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'os_diskio'


class OsDiskioHistory(models.Model):
    ip = models.CharField(max_length=50)
    tags = models.CharField(max_length=100, blank=True, null=True)
    fdisk = models.CharField(max_length=50)
    disk_io_reads = models.BigIntegerField()
    disk_io_writes = models.BigIntegerField()
    create_time = models.DateTimeField()
    ymdhi = models.BigIntegerField(db_column='YmdHi')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'os_diskio_history'


class OsNet(models.Model):
    ip = models.CharField(max_length=50)
    tags = models.CharField(max_length=100, blank=True, null=True)
    if_descr = models.CharField(max_length=50)
    in_bytes = models.BigIntegerField()
    out_bytes = models.BigIntegerField()
    create_time = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'os_net'


class OsNetHistory(models.Model):
    ip = models.CharField(max_length=50)
    tags = models.CharField(max_length=100, blank=True, null=True)
    if_descr = models.CharField(max_length=50)
    in_bytes = models.BigIntegerField()
    out_bytes = models.BigIntegerField()
    create_time = models.DateTimeField()
    ymdhi = models.BigIntegerField(db_column='YmdHi')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'os_net_history'


class OsStatus(models.Model):
    ip = models.CharField(max_length=50)
    snmp = models.IntegerField()
    tags = models.CharField(max_length=100, blank=True, null=True)
    hostname = models.CharField(max_length=100)
    kernel = models.CharField(max_length=50)
    system_date = models.CharField(max_length=50)
    system_uptime = models.CharField(max_length=50)
    process = models.SmallIntegerField()
    load_1 = models.DecimalField(max_digits=4, decimal_places=2)
    load_5 = models.DecimalField(max_digits=4, decimal_places=2)
    load_15 = models.DecimalField(max_digits=4, decimal_places=2)
    cpu_user_time = models.IntegerField()
    cpu_system_time = models.IntegerField()
    cpu_idle_time = models.IntegerField()
    swap_total = models.IntegerField()
    swap_avail = models.IntegerField()
    mem_total = models.IntegerField()
    mem_used = models.IntegerField()
    mem_free = models.IntegerField()
    mem_shared = models.IntegerField()
    mem_buffered = models.IntegerField()
    mem_cached = models.IntegerField()
    mem_usage_rate = models.CharField(max_length=50)
    mem_available = models.CharField(max_length=50)
    disk_io_reads_total = models.IntegerField()
    disk_io_writes_total = models.IntegerField()
    net_in_bytes_total = models.BigIntegerField()
    net_out_bytes_total = models.BigIntegerField()
    create_time = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'os_status'


class OsStatusHistory(models.Model):
    ip = models.CharField(max_length=50)
    snmp = models.IntegerField()
    tags = models.CharField(max_length=100, blank=True, null=True)
    hostname = models.CharField(max_length=100)
    kernel = models.CharField(max_length=50)
    system_date = models.CharField(max_length=50)
    system_uptime = models.CharField(max_length=50)
    process = models.SmallIntegerField()
    load_1 = models.DecimalField(max_digits=4, decimal_places=2)
    load_5 = models.DecimalField(max_digits=4, decimal_places=2)
    load_15 = models.DecimalField(max_digits=4, decimal_places=2)
    cpu_user_time = models.IntegerField()
    cpu_system_time = models.IntegerField()
    cpu_idle_time = models.IntegerField()
    swap_total = models.IntegerField()
    swap_avail = models.IntegerField()
    mem_total = models.IntegerField()
    mem_used = models.IntegerField()
    mem_free = models.IntegerField()
    mem_shared = models.IntegerField()
    mem_buffered = models.IntegerField()
    mem_cached = models.IntegerField()
    mem_usage_rate = models.CharField(max_length=50)
    mem_available = models.CharField(max_length=50)
    disk_io_reads_total = models.IntegerField()
    disk_io_writes_total = models.IntegerField()
    net_in_bytes_total = models.BigIntegerField()
    net_out_bytes_total = models.BigIntegerField()
    create_time = models.DateTimeField(blank=True, null=True)
    ymdhi = models.BigIntegerField(db_column='YmdHi')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'os_status_history'


class RedisReplication(models.Model):
    server_id = models.SmallIntegerField()
    tags = models.CharField(max_length=50)
    host = models.CharField(max_length=30, blank=True, null=True)
    port = models.SmallIntegerField(blank=True, null=True)
    role = models.CharField(max_length=20, blank=True, null=True)
    master_server_id = models.SmallIntegerField()
    master_host = models.CharField(max_length=20, blank=True, null=True)
    master_port = models.CharField(max_length=20, blank=True, null=True)
    master_link_status = models.CharField(max_length=20, blank=True, null=True)
    master_last_io_seconds_ago = models.CharField(max_length=20, blank=True, null=True)
    master_sync_in_progress = models.CharField(max_length=20, blank=True, null=True)
    slave_priority = models.CharField(max_length=20, blank=True, null=True)
    slave_read_only = models.CharField(max_length=20, blank=True, null=True)
    connected_slaves = models.SmallIntegerField(blank=True, null=True)
    create_time = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'redis_replication'


class RedisReplicationHistory(models.Model):
    server_id = models.SmallIntegerField()
    tags = models.CharField(max_length=50)
    host = models.CharField(max_length=20, blank=True, null=True)
    port = models.SmallIntegerField(blank=True, null=True)
    role = models.CharField(max_length=20, blank=True, null=True)
    master_server_id = models.SmallIntegerField()
    master_host = models.CharField(max_length=20, blank=True, null=True)
    master_port = models.CharField(max_length=20, blank=True, null=True)
    master_link_status = models.CharField(max_length=20, blank=True, null=True)
    master_last_io_seconds_ago = models.CharField(max_length=20, blank=True, null=True)
    master_sync_in_progress = models.CharField(max_length=20, blank=True, null=True)
    slave_priority = models.CharField(max_length=20, blank=True, null=True)
    slave_read_only = models.CharField(max_length=20, blank=True, null=True)
    connected_slaves = models.SmallIntegerField(blank=True, null=True)
    create_time = models.DateTimeField()
    ymdhi = models.BigIntegerField()

    class Meta:
        managed = False
        db_table = 'redis_replication_history'


class RedisStatus(models.Model):
    server_id = models.SmallIntegerField()
    host = models.CharField(max_length=30)
    port = models.CharField(max_length=10)
    tags = models.CharField(max_length=50)
    connect = models.SmallIntegerField()
    redis_role = models.CharField(max_length=30)
    redis_version = models.CharField(max_length=50)
    redis_git_sha1 = models.CharField(max_length=255)
    redis_git_dirty = models.CharField(max_length=255)
    redis_mode = models.CharField(max_length=255)
    os = models.CharField(max_length=255)
    arch_bits = models.CharField(max_length=10)
    multiplexing_api = models.CharField(max_length=20)
    gcc_version = models.CharField(max_length=20)
    process_id = models.IntegerField()
    run_id = models.CharField(max_length=255)
    tcp_port = models.IntegerField()
    uptime_in_seconds = models.IntegerField()
    uptime_in_days = models.IntegerField()
    hz = models.IntegerField()
    lru_clock = models.BigIntegerField()
    connected_clients = models.IntegerField()
    client_longest_output_list = models.IntegerField()
    client_biggest_input_buf = models.IntegerField()
    blocked_clients = models.SmallIntegerField()
    used_memory = models.BigIntegerField()
    used_memory_human = models.CharField(max_length=50)
    used_memory_rss = models.CharField(max_length=50)
    used_memory_peak = models.CharField(max_length=50)
    used_memory_peak_human = models.CharField(max_length=50)
    used_memory_lua = models.CharField(max_length=50)
    mem_fragmentation_ratio = models.CharField(max_length=50)
    mem_allocator = models.CharField(max_length=50)
    loading = models.SmallIntegerField()
    rdb_changes_since_last_save = models.BigIntegerField(blank=True, null=True)
    rdb_bgsave_in_progress = models.SmallIntegerField()
    rdb_last_save_time = models.BigIntegerField()
    rdb_last_bgsave_status = models.CharField(max_length=10)
    rdb_last_bgsave_time_sec = models.SmallIntegerField()
    rdb_current_bgsave_time_sec = models.SmallIntegerField()
    aof_enabled = models.SmallIntegerField()
    aof_rewrite_in_progress = models.SmallIntegerField()
    aof_rewrite_scheduled = models.SmallIntegerField()
    aof_last_rewrite_time_sec = models.SmallIntegerField()
    aof_current_rewrite_time_sec = models.SmallIntegerField()
    aof_last_bgrewrite_status = models.CharField(max_length=10)
    total_connections_received = models.IntegerField()
    total_commands_processed = models.BigIntegerField(blank=True, null=True)
    current_commands_processed = models.IntegerField()
    instantaneous_ops_per_sec = models.IntegerField()
    rejected_connections = models.SmallIntegerField()
    expired_keys = models.IntegerField()
    evicted_keys = models.IntegerField()
    keyspace_hits = models.BigIntegerField()
    keyspace_misses = models.BigIntegerField(blank=True, null=True)
    pubsub_channels = models.IntegerField()
    pubsub_patterns = models.IntegerField()
    latest_fork_usec = models.IntegerField()
    used_cpu_sys = models.DecimalField(max_digits=10, decimal_places=2)
    used_cpu_user = models.FloatField()
    used_cpu_sys_children = models.IntegerField()
    used_cpu_user_children = models.IntegerField()
    create_time = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'redis_status'


class RedisStatusHistory(models.Model):
    server_id = models.SmallIntegerField()
    host = models.CharField(max_length=30)
    port = models.CharField(max_length=10)
    tags = models.CharField(max_length=50)
    connect = models.SmallIntegerField()
    redis_role = models.CharField(max_length=30)
    redis_version = models.CharField(max_length=50)
    redis_git_sha1 = models.CharField(max_length=255)
    redis_git_dirty = models.CharField(max_length=255)
    redis_mode = models.CharField(max_length=255)
    os = models.CharField(max_length=255)
    arch_bits = models.CharField(max_length=10)
    multiplexing_api = models.CharField(max_length=20)
    gcc_version = models.CharField(max_length=20)
    process_id = models.IntegerField()
    run_id = models.CharField(max_length=255)
    tcp_port = models.IntegerField()
    uptime_in_seconds = models.IntegerField()
    uptime_in_days = models.IntegerField()
    hz = models.IntegerField()
    lru_clock = models.BigIntegerField()
    connected_clients = models.SmallIntegerField()
    client_longest_output_list = models.IntegerField()
    client_biggest_input_buf = models.IntegerField()
    blocked_clients = models.SmallIntegerField()
    used_memory = models.BigIntegerField()
    used_memory_human = models.CharField(max_length=50)
    used_memory_rss = models.CharField(max_length=50)
    used_memory_peak = models.CharField(max_length=50)
    used_memory_peak_human = models.CharField(max_length=50)
    used_memory_lua = models.CharField(max_length=50)
    mem_fragmentation_ratio = models.CharField(max_length=50)
    mem_allocator = models.CharField(max_length=50)
    loading = models.SmallIntegerField()
    rdb_changes_since_last_save = models.BigIntegerField(blank=True, null=True)
    rdb_bgsave_in_progress = models.SmallIntegerField()
    rdb_last_save_time = models.BigIntegerField()
    rdb_last_bgsave_status = models.CharField(max_length=10)
    rdb_last_bgsave_time_sec = models.SmallIntegerField()
    rdb_current_bgsave_time_sec = models.SmallIntegerField()
    aof_enabled = models.SmallIntegerField()
    aof_rewrite_in_progress = models.SmallIntegerField()
    aof_rewrite_scheduled = models.SmallIntegerField()
    aof_last_rewrite_time_sec = models.SmallIntegerField()
    aof_current_rewrite_time_sec = models.SmallIntegerField()
    aof_last_bgrewrite_status = models.CharField(max_length=10)
    total_connections_received = models.IntegerField()
    total_commands_processed = models.BigIntegerField(blank=True, null=True)
    current_commands_processed = models.IntegerField()
    instantaneous_ops_per_sec = models.IntegerField()
    rejected_connections = models.SmallIntegerField()
    expired_keys = models.IntegerField()
    evicted_keys = models.IntegerField()
    keyspace_hits = models.BigIntegerField()
    keyspace_misses = models.BigIntegerField(blank=True, null=True)
    pubsub_channels = models.IntegerField()
    pubsub_patterns = models.IntegerField()
    latest_fork_usec = models.IntegerField()
    used_cpu_sys = models.DecimalField(max_digits=10, decimal_places=2)
    used_cpu_user = models.FloatField()
    used_cpu_sys_children = models.IntegerField()
    used_cpu_user_children = models.IntegerField()
    create_time = models.DateTimeField()
    ymdhi = models.BigIntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'redis_status_history'

class ScriptAutoIssued(models.Model):
    id = models.IntegerField(primary_key=True)
    issued_button = models.CharField(unique=True, max_length=200)
    script_path = models.CharField(max_length=450)
    functions = models.CharField(max_length=300, blank=True)
    class Meta:
        db_table = 'script_auto_issued'

class ScriptAutoIssuedHostlist(models.Model):
    id = models.IntegerField(primary_key=True)
    issued_button = models.CharField(max_length=600)
    ansible_host_group = models.CharField(max_length=900)
    functions = models.CharField(max_length=300)
    class Meta:
        db_table = 'script_auto_issued_hostlist'

class User(models.Model):
    username = models.CharField(max_length=10)
    password = models.CharField(max_length=10)

    class Meta:
        managed = False
        db_table = 'user'
