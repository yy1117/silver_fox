#!/usr/bin/env python
#coding:utf-8
import os
import sys
import string
import time
import datetime
import MySQLdb
import ConfigParser #文件解析
path='./include'
sys.path.insert(0,path)
import functions as func
from multiprocessing import Process;


def dml_analysis(host,port,username,password,tags):
	try:
		conn=MySQLdb.connect(host=host,user=username,passwd=password,port=int(port),connect_timeout=2,charset='utf8')
        	curs=conn.cursor()
		try:
			dml_db=curs.execute("show binary logs;");
			#return dml_db
			#result=curs.fetchall()
			#return result
			if dml_db:
				for rows in curs.fetchall():
					datalist = []
					for row in rows:
						datalist.append(row)	
					results = datalist
					#return datalist
					#print results
					if results:
						binlog_name=results[0]
						binlog_size=results[1]
 			                        sql="insert into binlog_dml(host,port,tags,binlog_name,binlog_size) values(%s,%s,%s,%s,%s);"
                          			param=(host,port,tags,results[0],results[1])
                          			func.mysql_exec(sql,param)
			#curs.close()
			#conn.close()				
		except:
			pass
			
	except MySQLdb.Error,e:
        	pass
        	print "Mysql Error %d: %s" %(e.args[0],e.args[1])
		

#print dml_analysis('118.178.133.208','3306','mha_mon','bTeIBfyNOR','big_data_testing')
#def binlog_insert_db():
def main():
    #func.mysql_exec("insert into mysql_bigtable_history SELECT *,LEFT(REPLACE(REPLACE(REPLACE(create_time,'-',''),' ',''),':',''),8) from mysql_bigtable",'')
    #mysql_exec("insert into mysql_bigtable_history SELECT *,LEFT(REPLACE(REPLACE(REPLACE(create_time,'-',''),' ',''),':',''),8) from mysql_bigtable",'')
    #func.mysql_exec('delete from mysql_bigtable;','')
    #mysql_exec('delete from mysql_bigtable;','')
    #get mysql servers list
	servers = func.mysql_query('SELECT HOST,PORT,username,PASSWORD,tags FROM db_servers_mysql;')
    #servers = func.mysql_query('show binary logs;')
    #return servers
	if servers:
		print("%s: check mysql bigtable controller started." % (time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()),));
		serlist = []
		for s in servers:
			host = s[0]
			port = s[1]
			username = s[2]
			password = s[3]
			tags = s[4]
			p = Process(target = dml_analysis, args = (host,port,username,password,tags))
			serlist.append(p)	
		#return serlist	
		for p in serlist:
			p.start()
		time.sleep(20)
		for p in serlist:
			p.terminate()
		for p in serlist:
			p.join
		print("%s: check mysql bigtable controller finished." % (time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()),))	



#print binlog_insert_db();

if __name__ == '__main__':
	main()
