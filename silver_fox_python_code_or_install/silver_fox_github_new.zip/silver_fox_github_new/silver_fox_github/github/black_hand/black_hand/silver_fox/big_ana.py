#!/usr/bin/python
#coding:utf-8


import MySQLdb,sys,os
reload(sys)
import MySQLdb,re
import ConfigParser #文件解析

def get_config(group,config_name):
    cp = ConfigParser.SafeConfigParser(allow_no_value = True)
    b = os.path.abspath('./etc/config.ini')
    cp.readfp(open(b,'rw'))
    config_value=cp.get(group,config_name).strip(' ').strip('\'').strip('\"')
    return config_value


host1  = get_config('monitor_server','host')
port1 = get_config('monitor_server','port')
user1 = get_config('monitor_server','user')
passwd1 = get_config('monitor_server','passwd')
dbname1 = get_config('monitor_server','dbname')

conn1=MySQLdb.connect(host="localhost",user='root',passwd='root',port=3306,db="django",read_default_file="/etc/my.cnf",charset="utf8",unix_socket='/tmp/mysql.sock')
cursor=conn1.cursor()


def get_big_mess():
        try:
                cursor.execute('SELECT host,tags,db_name,table_name,CONCAT(table_size,"MB") table_size_mb,table_rows FROM mysql_bigtable')
                row1 = cursor.fetchall()

                results = []
                for infor in row1:
                        results.append({'host':infor[0],'tags':infor[1],'db_name':infor[2],'table_name':infor[3],'table_size_mb':infor[4],'table_rows':infor[5]})
                return results
		#cursor.close()
		#conn1.close()
        except Exception as e:
                print e



print get_big_mess()
