#-*- coding:utf8 -*-
import sys,os
reload(sys)
import MySQLdb,re
import ConfigParser #文件解析
def get_config(group,config_name):
    cp = ConfigParser.SafeConfigParser(allow_no_value = True)
    b = os.path.abspath('./etc/config.ini')
    cp.readfp(open(b,'rw'))
    config_value=cp.get(group,config_name).strip(' ').strip('\'').strip('\"')
    return config_value

#fh = open('/root/csvt01/blog/etc/config.ini','rw')
#def get_config(monitor_name,name):
#	while True:
#		i = fh.readline()

#		if i == '':
#			break
#		a= i.strip(' ').strip('\'').replace('"','').strip('\n').split('=')	
#		if a[0] == str(name):
#			return a[1] 

host1  = get_config('monitor_server','host')
port1 = get_config('monitor_server','port')
user1 = get_config('monitor_server','user')
passwd1 = get_config('monitor_server','passwd')
dbname1 = get_config('monitor_server','dbname')


def auto(w_re):
                conn=MySQLdb.connect(host=str(host1),user=str(user1),passwd=str(passwd1),port=3306,db=str(dbname1),read_default_file="/etc/my.cnf",charset="utf8",unix_socket='/tmp/mysql.sock')
                cursor=conn.cursor()
                sql = w_re
                cursor.execute(sql)
                row = cursor.fetchall()
		results = []
		n = ''
		for i in row:
			#统计col个数
			cnt_index = len(i)
			cnt = []
			for j in range(cnt_index):
				cnt.append(str(i[j]))
			results.append(cnt)
		return results
		cursor.close()
		conn.close()



