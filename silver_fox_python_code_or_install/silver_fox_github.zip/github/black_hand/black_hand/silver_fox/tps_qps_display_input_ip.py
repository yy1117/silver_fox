#!/usr/bin/python
#-*- coding:utf8 -*-
#namex = sys.argv[1]
import sys,os,re,MySQLdb
reload(sys)
import MySQLdb,re
import ConfigParser #文件解析

def get_config(group,config_name):
    cp = ConfigParser.SafeConfigParser(allow_no_value = True)
    #b = str(os.getcwd())
    b = os.path.abspath('./etc/config.ini')
    #html 报错说目录在/root/csvt01/etc/config.ini 做做了个软连接过去
    cp.readfp(open(b,'rw'))
    config_value=cp.get(group,config_name).strip(' ').strip('\'').strip('\"')
    return config_value

host1  = get_config('monitor_server','host')
port1 = get_config('monitor_server','port')
user1 = get_config('monitor_server','user')
passwd1 = get_config('monitor_server','passwd')
dbname1 = get_config('monitor_server','dbname')

conn1=MySQLdb.connect(host="localhost",user=str(user1),passwd=str(passwd1),port=3306,db=str(dbname1),read_default_file="/etc/my.cnf",charset="utf8",unix_socket='/tmp/mysql.sock')
cursor=conn1.cursor()

def get_server_info(ip,index):
	try:
		cursor.execute('SELECT * FROM (  SELECT HOST,create_time,com_select_persecond,com_insert_persecond,com_update_persecond,com_delete_persecond,questions_persecond,(com_insert_persecond + com_update_persecond + com_delete_persecond),com_commit_persecond,com_rollback_persecond,threads_connected,threads_running,connections,innodb_buffer_pool_read_requests_persecond,innodb_buffer_pool_reads_persecond,innodb_rows_read_persecond,innodb_rows_inserted_persecond,innodb_rows_updated_persecond,innodb_rows_deleted_persecond FROM mysql_status_history  WHERE create_time >= DATE_SUB(NOW(),INTERVAL 30 MINUTE) AND HOST="%s" UNION ALL SELECT HOST,create_time,com_select_persecond,com_insert_persecond,com_update_persecond,com_delete_persecond,questions_persecond,(com_insert_persecond + com_update_persecond + com_delete_persecond),com_commit_persecond,com_rollback_persecond,threads_connected,threads_running,connections,innodb_buffer_pool_read_requests_persecond,innodb_buffer_pool_reads_persecond,innodb_rows_read_persecond,innodb_rows_inserted_persecond,innodb_rows_updated_persecond,innodb_rows_deleted_persecond FROM mysql_status WHERE create_time >= DATE_SUB(NOW(),INTERVAL 30 MINUTE) AND HOST="%s") c  LIMIT 1000 ;' % (ip,ip))	
		row1 = cursor.fetchall()
		
		#results = []
		results = ""
		end_results = ""
		#for server_id,host,port,tag in row1:
		i = 1
		#行记录 row_count
		cnt = cursor.rowcount
		for infor in row1:
			#下面的循环是把每行的记录指定的index位置的值,转换成一行记录(类似列转行)
			if int(cnt) != i:
				results += str(infor[index]) + ','
				#指定分隔符号
				#results += str(infor[index]) + '%'
			else:
				end_results = str(infor[index])
			i = i + 1
		result = results + end_results
		return result
		#return cursor,result
		#cursor.close()
		#conn1.close()
	except Exception as e:
		print e	





