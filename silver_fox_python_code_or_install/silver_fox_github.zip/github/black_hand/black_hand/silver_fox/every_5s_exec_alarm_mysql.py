#!/usr/bin/python
# -*- coding:utf-8 -*-
import os
import time
def sleeptime(hour,min,sec):
	return hour*3600 + min*60 + sec
second = sleeptime(0,0,10)
while 1==1:
	time.sleep(5)
	os.system('python alarm.py')
